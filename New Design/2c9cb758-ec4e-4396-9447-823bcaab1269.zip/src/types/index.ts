export type CategorySlug =
'shopping' |
'promotional' |
'corporate' |
'custom' |
'eco';

export interface Product {
  id: string;
  name: string;
  tagline: string;
  description: string;
  price: number;
  compareAt?: number;
  rating: number;
  reviews: number;
  image: string;
  category: CategorySlug;
  inStock: boolean;
  badge?: string;
  specs: {label: string;value: string;}[];
}

export interface Category {
  slug: CategorySlug;
  name: string;
  blurb: string;
  image: string;
  count: number;
}

export interface CartLine {
  product: Product;
  qty: number;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  quote: string;
  rating: number;
  initials: string;
}

export type OrderStatus = 'placed' | 'packed' | 'shipped' | 'delivered';

export interface Order {
  id: string;
  placedAt: string;
  lines: CartLine[];
  total: number;
  status: OrderStatus;
  address: string;
}
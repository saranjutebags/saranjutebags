import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckIcon, LeafIcon, PackageSearchIcon } from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Button } from '../components/ui/Button';
import { formatPrice } from '../utils/format';
import { NotFound } from './NotFound';

export function OrderConfirmation() {
  const { id } = useParams();
  const { orders } = useStore();
  const order = orders.find((o) => o.id === id);

  if (!order) return <NotFound />;

  const eta = new Date(Date.now() + 4 * 86400000).toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short'
  });

  return (
    <div className="mx-auto max-w-2xl px-5 pb-16 pt-12 sm:px-8">
      <div className="flex flex-col items-center text-center">
        <motion.span
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
          className="grid h-16 w-16 place-items-center rounded-full bg-forest-700 text-sand-50">
          
          <CheckIcon className="h-8 w-8" aria-hidden="true" />
        </motion.span>
        <h1 className="mt-6 font-display text-4xl leading-tight tracking-[-0.025em] text-forest-800">
          Order confirmed
        </h1>
        <p className="mt-3 max-w-md text-[15px] leading-relaxed text-ink-soft">
          Thanks — we've emailed your receipt. Your bags leave our Kolkata unit
          within 24 hours, packed in recycled kraft.
        </p>
      </div>

      <div className="mt-9 rounded-4xl border border-ink-line/70 bg-white p-6 shadow-soft sm:p-7">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-ink-line pb-5">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-muted">
              Order number
            </p>
            <p className="mt-1 font-display text-xl text-forest-800">{order.id}</p>
          </div>
          <div className="text-right">
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-muted">
              Estimated delivery
            </p>
            <p className="mt-1 font-display text-xl text-forest-800">{eta}</p>
          </div>
        </div>

        <ul className="mt-5 space-y-3.5">
          {order.lines.map((line) =>
          <li key={line.product.id} className="flex items-center gap-3">
              <img
              src={line.product.image}
              alt=""
              className="h-14 w-14 shrink-0 rounded-2xl object-cover" />
            
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-forest-800">
                  {line.product.name}
                </p>
                <p className="text-xs text-ink-muted">Qty {line.qty}</p>
              </div>
              <span className="text-sm font-semibold text-forest-800">
                {formatPrice(line.product.price * line.qty)}
              </span>
            </li>
          )}
        </ul>

        <div className="mt-5 flex items-center justify-between border-t border-ink-line pt-5">
          <span className="text-sm text-ink-soft">Total paid</span>
          <span className="font-display text-xl text-forest-800">
            {formatPrice(order.total)}
          </span>
        </div>

        <div className="mt-5 rounded-3xl bg-sand-50 p-4">
          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-muted">
            Shipping to
          </p>
          <p className="mt-1 text-sm text-ink">{order.address}</p>
        </div>
      </div>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <Link to={`/track/${order.id}`} className="flex-1">
          <Button
            fullWidth
            size="lg"
            icon={<PackageSearchIcon className="h-4 w-4" aria-hidden="true" />}>
            
            Track this order
          </Button>
        </Link>
        <Link to="/products" className="flex-1">
          <Button fullWidth size="lg" variant="secondary">
            Continue shopping
          </Button>
        </Link>
      </div>

      <p className="mt-8 flex items-center justify-center gap-2 text-[13px] text-forest-600">
        <LeafIcon className="h-4 w-4" aria-hidden="true" />
        This order keeps an estimated 2,100 plastic bags out of circulation.
      </p>
    </div>);

}
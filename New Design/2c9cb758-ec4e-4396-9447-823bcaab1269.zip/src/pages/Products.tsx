import React from 'react';
import { useSearchParams } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { SearchIcon, SlidersHorizontalIcon, XIcon } from 'lucide-react';
import { products } from '../data/products';
import { categories } from '../data/site';
import { ProductCard } from '../components/product/ProductCard';
import { ProductCardSkeleton } from '../components/ui/Skeleton';
import { Button } from '../components/ui/Button';
import { cn, formatPrice } from '../utils/format';
import type { Product } from '../types';

type SortKey = 'featured' | 'price-asc' | 'price-desc' | 'rating';

const sortOptions: {key: SortKey;label: string;}[] = [
{ key: 'featured', label: 'Featured' },
{ key: 'price-asc', label: 'Price: low to high' },
{ key: 'price-desc', label: 'Price: high to low' },
{ key: 'rating', label: 'Top rated' }];


const priceBands = [
{ key: 'all', label: 'Any price', test: () => true },
{ key: 'under-500', label: 'Under ₹500', test: (p: Product) => p.price < 500 },
{ key: '500-1500', label: '₹500 – ₹1,500', test: (p: Product) => p.price >= 500 && p.price <= 1500 },
{ key: 'over-1500', label: 'Over ₹1,500', test: (p: Product) => p.price > 1500 }];


export function Products() {
  const [params, setParams] = useSearchParams();
  const [loading, setLoading] = React.useState(true);
  const [filtersOpen, setFiltersOpen] = React.useState(false);
  const [sort, setSort] = React.useState<SortKey>('featured');
  const [band, setBand] = React.useState('all');
  const [inStockOnly, setInStockOnly] = React.useState(false);

  const query = params.get('q') ?? '';
  const category = params.get('category') ?? 'all';

  React.useEffect(() => {
    setLoading(true);
    const t = window.setTimeout(() => setLoading(false), 550);
    return () => window.clearTimeout(t);
  }, [query, category, band, sort, inStockOnly]);

  const setParam = (key: string, value: string | null) => {
    const next = new URLSearchParams(params);
    if (!value || value === 'all') next.delete(key);else
    next.set(key, value);
    setParams(next, { replace: true });
  };

  const results = React.useMemo(() => {
    const bandTest = priceBands.find((b) => b.key === band)?.test ?? (() => true);
    let list = products.filter((p) => {
      const matchesQuery =
      !query ||
      `${p.name} ${p.description} ${p.tagline}`.
      toLowerCase().
      includes(query.toLowerCase());
      const matchesCategory = category === 'all' || p.category === category;
      const matchesStock = !inStockOnly || p.inStock;
      return matchesQuery && matchesCategory && matchesStock && bandTest(p);
    });
    if (sort === 'price-asc') list = [...list].sort((a, b) => a.price - b.price);
    if (sort === 'price-desc') list = [...list].sort((a, b) => b.price - a.price);
    if (sort === 'rating') list = [...list].sort((a, b) => b.rating - a.rating);
    return list;
  }, [query, category, band, sort, inStockOnly]);

  const activeFilters =
  (category !== 'all' ? 1 : 0) + (band !== 'all' ? 1 : 0) + (inStockOnly ? 1 : 0);

  const clearAll = () => {
    setBand('all');
    setInStockOnly(false);
    setParams(new URLSearchParams(), { replace: true });
  };

  const filterPanel =
  <div className="space-y-7">
      <fieldset>
        <legend className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-muted">
          Category
        </legend>
        <div className="mt-3 space-y-1">
          {[{ slug: 'all', name: 'All collections' }, ...categories].map((c) =>
        <button
          key={c.slug}
          onClick={() => setParam('category', c.slug)}
          className={cn(
            'block w-full rounded-xl px-3 py-2 text-left text-sm transition-colors duration-200 ease-premium',
            category === c.slug ?
            'bg-forest-50 font-medium text-forest-700' :
            'text-ink-soft hover:bg-sand-50'
          )}>
          
              {c.name}
            </button>
        )}
        </div>
      </fieldset>

      <fieldset className="border-t border-ink-line pt-6">
        <legend className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-muted">
          Price
        </legend>
        <div className="mt-3 space-y-1">
          {priceBands.map((b) =>
        <button
          key={b.key}
          onClick={() => setBand(b.key)}
          className={cn(
            'block w-full rounded-xl px-3 py-2 text-left text-sm transition-colors duration-200 ease-premium',
            band === b.key ?
            'bg-forest-50 font-medium text-forest-700' :
            'text-ink-soft hover:bg-sand-50'
          )}>
          
              {b.label}
            </button>
        )}
        </div>
      </fieldset>

      <div className="border-t border-ink-line pt-6">
        <label className="flex cursor-pointer items-center justify-between gap-3">
          <span className="text-sm text-ink-soft">In stock only</span>
          <input
          type="checkbox"
          checked={inStockOnly}
          onChange={(e) => setInStockOnly(e.target.checked)}
          className="h-4 w-4 rounded border-ink-line text-forest-700 focus:ring-forest-500" />
        
        </label>
      </div>

      {activeFilters > 0 &&
    <Button variant="ghost" size="sm" onClick={clearAll} fullWidth>
          Clear all filters
        </Button>
    }
    </div>;


  return (
    <div className="mx-auto max-w-[1240px] px-5 pb-16 pt-8 sm:px-8 sm:pt-12">
      <header className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-forest-500">
          Shop
        </p>
        <h1 className="mt-3 font-display text-4xl leading-[1.1] tracking-[-0.025em] text-forest-800 sm:text-[46px]">
          {query ? `Results for “${query}”` : 'The full jute collection'}
        </h1>
        <p className="mt-3 text-[15px] leading-relaxed text-ink-soft">
          Every bag ships plastic-free. Free delivery over {formatPrice(1500)}.
        </p>
      </header>

      <div className="mt-9 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2 rounded-full border border-ink-line bg-white px-4 py-2.5 sm:max-w-sm sm:flex-1">
          <SearchIcon className="h-4 w-4 shrink-0 text-ink-muted" aria-hidden="true" />
          <input
            value={query}
            onChange={(e) => setParam('q', e.target.value)}
            placeholder="Search by name or use"
            aria-label="Search products"
            className="w-full bg-transparent text-sm text-ink placeholder:text-ink-muted focus:outline-none" />
          
          {query &&
          <button
            onClick={() => setParam('q', null)}
            aria-label="Clear search"
            className="rounded-full p-0.5 text-ink-muted hover:text-ink">
            
              <XIcon className="h-4 w-4" aria-hidden="true" />
            </button>
          }
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="sm"
            className="lg:hidden"
            icon={<SlidersHorizontalIcon className="h-4 w-4" aria-hidden="true" />}
            onClick={() => setFiltersOpen(true)}>
            
            Filters{activeFilters > 0 ? ` (${activeFilters})` : ''}
          </Button>
          <label className="sr-only" htmlFor="sort">
            Sort products
          </label>
          <select
            id="sort"
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            className="h-9 rounded-full border border-ink-line bg-white px-4 text-[13px] font-medium text-ink-soft transition-colors duration-200 ease-premium hover:border-forest-300 focus:outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-forest-500">
            
            {sortOptions.map((o) =>
            <option key={o.key} value={o.key}>
                {o.label}
              </option>
            )}
          </select>
        </div>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[220px_1fr]">
        <aside className="hidden lg:block" aria-label="Filters">
          <div className="sticky top-28 rounded-4xl border border-ink-line/70 bg-white p-5 shadow-soft">
            {filterPanel}
          </div>
        </aside>

        <div>
          <p className="mb-4 text-[13px] text-ink-muted" aria-live="polite">
            {loading ? 'Loading products…' : `${results.length} products`}
          </p>

          {loading ?
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {[0, 1, 2, 3, 4, 5].map((i) =>
            <ProductCardSkeleton key={i} />
            )}
            </div> :
          results.length === 0 ?
          <div className="rounded-4xl border border-dashed border-ink-line bg-white/60 px-6 py-16 text-center">
              <h2 className="font-display text-xl text-forest-800">
                No bags match those filters
              </h2>
              <p className="mx-auto mt-2 max-w-sm text-sm text-ink-soft">
                Try widening the price range or clearing the search term.
              </p>
              <Button className="mt-6" variant="secondary" onClick={clearAll}>
                Reset filters
              </Button>
            </div> :

          <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {results.map((product) =>
            <li key={product.id} className="h-full">
                  <ProductCard product={product} />
                </li>
            )}
            </ul>
          }
        </div>
      </div>

      <AnimatePresence>
        {filtersOpen &&
        <div className="fixed inset-0 z-[80] lg:hidden">
            <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={() => setFiltersOpen(false)}
            className="absolute inset-0 bg-forest-900/35 backdrop-blur-sm" />
          
            <motion.div
            role="dialog"
            aria-modal="true"
            aria-label="Filters"
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ duration: 0.28, ease: [0.23, 1, 0.32, 1] }}
            className="absolute inset-x-0 bottom-0 max-h-[85vh] overflow-y-auto rounded-t-4xl border-t border-white/70 bg-white/92 p-5 pb-8 shadow-lift backdrop-blur-2xl">
            
              <div className="mb-5 flex items-center justify-between">
                <h2 className="font-display text-xl text-forest-800">Filters</h2>
                <button
                onClick={() => setFiltersOpen(false)}
                aria-label="Close filters"
                className="grid h-9 w-9 place-items-center rounded-full text-ink-soft hover:bg-sand-100">
                
                  <XIcon className="h-4 w-4" aria-hidden="true" />
                </button>
              </div>
              {filterPanel}
              <Button
              fullWidth
              size="lg"
              className="mt-7"
              onClick={() => setFiltersOpen(false)}>
              
                Show {results.length} products
              </Button>
            </motion.div>
          </div>
        }
      </AnimatePresence>
    </div>);

}
import React from 'react';
import { Link } from 'react-router-dom';
import {
  HeartIcon,
  LeafIcon,
  MapPinIcon,
  PackageIcon,
  SettingsIcon } from
'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Button } from '../components/ui/Button';
import { formatPrice } from '../utils/format';

export function Profile() {
  const { orders, wishlist } = useStore();

  const stats = [
  { label: 'Orders placed', value: String(orders.length), Icon: PackageIcon },
  { label: 'Saved bags', value: String(wishlist.length), Icon: HeartIcon },
  { label: 'Plastic avoided', value: '2.1k', Icon: LeafIcon }];


  return (
    <div className="mx-auto max-w-[1000px] px-5 pb-16 pt-8 sm:px-8 sm:pt-12">
      <header className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <span className="grid h-16 w-16 shrink-0 place-items-center rounded-3xl bg-forest-700 font-display text-xl text-sand-50">
            RN
          </span>
          <div>
            <h1 className="font-display text-3xl tracking-[-0.02em] text-forest-800">
              Riya Nair
            </h1>
            <p className="mt-1 text-sm text-ink-soft">riya.nair@example.com</p>
          </div>
        </div>
        <Button
          variant="secondary"
          icon={<SettingsIcon className="h-4 w-4" aria-hidden="true" />}>
          
          Account settings
        </Button>
      </header>

      <dl className="mt-8 grid grid-cols-3 gap-3">
        {stats.map((stat) =>
        <div
          key={stat.label}
          className="rounded-3xl border border-ink-line/70 bg-white p-4 shadow-soft">
          
            <stat.Icon className="h-4 w-4 text-forest-500" aria-hidden="true" />
            <dt className="sr-only">{stat.label}</dt>
            <dd>
              <span className="mt-3 block font-display text-2xl text-forest-800">
                {stat.value}
              </span>
              <span className="mt-0.5 block text-xs text-ink-muted">{stat.label}</span>
            </dd>
          </div>
        )}
      </dl>

      <section className="mt-10">
        <h2 className="font-display text-2xl tracking-[-0.02em] text-forest-800">
          Previous orders
        </h2>

        {orders.length === 0 ?
        <div className="mt-5 rounded-4xl border border-dashed border-ink-line bg-white/60 px-6 py-16 text-center">
            <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-sand-100">
              <PackageIcon className="h-6 w-6 text-sand-600" aria-hidden="true" />
            </span>
            <h3 className="mt-4 font-display text-lg text-forest-800">
              No orders yet
            </h3>
            <p className="mx-auto mt-2 max-w-sm text-sm text-ink-soft">
              Once you place an order it will appear here with live tracking.
            </p>
            <Link to="/products" className="mt-5 inline-block">
              <Button>Order now</Button>
            </Link>
          </div> :

        <ul className="mt-5 space-y-3">
            {orders.map((order) =>
          <li
            key={order.id}
            className="rounded-4xl border border-ink-line/70 bg-white p-5 shadow-soft">
            
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <p className="font-display text-lg text-forest-800">{order.id}</p>
                    <p className="mt-0.5 text-[13px] text-ink-muted">
                      {new Date(order.placedAt).toLocaleDateString('en-IN', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                  })}{' '}
                      · {formatPrice(order.total)}
                    </p>
                  </div>
                  <span className="rounded-full bg-forest-50 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.1em] text-forest-700">
                    {order.status}
                  </span>
                </div>

                <ul className="mt-4 flex flex-wrap items-center gap-2">
                  {order.lines.map((line) =>
              <li key={line.product.id}>
                      <img
                  src={line.product.image}
                  alt={line.product.name}
                  className="h-12 w-12 rounded-xl object-cover" />
                
                    </li>
              )}
                </ul>

                <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-ink-line pt-4">
                  <p className="flex items-center gap-2 text-[13px] text-ink-soft">
                    <MapPinIcon className="h-4 w-4 shrink-0 text-ink-muted" aria-hidden="true" />
                    {order.address}
                  </p>
                  <Link to={`/track/${order.id}`}>
                    <Button size="sm" variant="secondary">
                      Track order
                    </Button>
                  </Link>
                </div>
              </li>
          )}
          </ul>
        }
      </section>
    </div>);

}
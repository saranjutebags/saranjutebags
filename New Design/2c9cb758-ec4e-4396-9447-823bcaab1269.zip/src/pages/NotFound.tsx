import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/Button';

export function NotFound() {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center px-5 py-28 text-center">
      <p className="font-display text-[64px] leading-none text-sand-300">404</p>
      <h1 className="mt-4 font-display text-3xl tracking-[-0.02em] text-forest-800">
        This page went back to soil
      </h1>
      <p className="mt-3 text-[15px] leading-relaxed text-ink-soft">
        The link you followed does not exist anymore. The collection is still
        right where you left it.
      </p>
      <Link to="/products" className="mt-7">
        <Button size="lg">Explore collection</Button>
      </Link>
    </div>);

}
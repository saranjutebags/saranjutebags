import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { CheckIcon, HomeIcon, PackageIcon, TruckIcon } from 'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Button } from '../components/ui/Button';
import { cn, formatPrice } from '../utils/format';
import { NotFound } from './NotFound';

const steps = [
{ key: 'placed', label: 'Order placed', detail: 'Payment confirmed', Icon: CheckIcon },
{ key: 'packed', label: 'Packed', detail: 'Kolkata fulfilment unit', Icon: PackageIcon },
{ key: 'shipped', label: 'In transit', detail: 'Handed to courier partner', Icon: TruckIcon },
{ key: 'delivered', label: 'Delivered', detail: 'Signed at your address', Icon: HomeIcon }];


export function OrderTracking() {
  const { id } = useParams();
  const { orders } = useStore();
  const order = orders.find((o) => o.id === id);

  if (!order) return <NotFound />;

  const currentIndex = 1;

  return (
    <div className="mx-auto max-w-2xl px-5 pb-16 pt-8 sm:px-8 sm:pt-12">
      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-forest-500">
        Tracking
      </p>
      <h1 className="mt-3 font-display text-4xl tracking-[-0.025em] text-forest-800">
        Order {order.id}
      </h1>
      <p className="mt-3 text-[15px] text-ink-soft">
        {formatPrice(order.total)} · {order.lines.length}{' '}
        {order.lines.length === 1 ? 'item' : 'items'} · shipping to {order.address}
      </p>

      <ol className="mt-10 space-y-0">
        {steps.map((step, i) => {
          const done = i <= currentIndex;
          const active = i === currentIndex;
          return (
            <li key={step.key} className="relative flex gap-5 pb-9 last:pb-0">
              {i < steps.length - 1 &&
              <span
                className={cn(
                  'absolute left-[19px] top-10 h-[calc(100%-24px)] w-0.5 rounded-full',
                  done ? 'bg-forest-300' : 'bg-ink-line'
                )}
                aria-hidden="true" />

              }
              <span
                className={cn(
                  'relative z-10 grid h-10 w-10 shrink-0 place-items-center rounded-full border-2',
                  done ?
                  'border-forest-700 bg-forest-700 text-sand-50' :
                  'border-ink-line bg-white text-ink-muted'
                )}>
                
                <step.Icon className="h-[18px] w-[18px]" aria-hidden="true" />
              </span>
              <div className="pt-1.5">
                <p
                  className={cn(
                    'text-[15px] font-semibold',
                    done ? 'text-forest-800' : 'text-ink-muted'
                  )}>
                  
                  {step.label}
                  {active &&
                  <span className="ml-2 rounded-full bg-forest-50 px-2 py-0.5 text-[11px] font-medium text-forest-700">
                      Current
                    </span>
                  }
                </p>
                <p className="mt-0.5 text-[13px] text-ink-soft">{step.detail}</p>
              </div>
            </li>);

        })}
      </ol>

      <div className="mt-8 rounded-4xl border border-ink-line/70 bg-white p-6 shadow-soft">
        <h2 className="font-display text-xl text-forest-800">In this shipment</h2>
        <ul className="mt-4 space-y-3.5">
          {order.lines.map((line) =>
          <li key={line.product.id} className="flex items-center gap-3">
              <img
              src={line.product.image}
              alt=""
              className="h-12 w-12 shrink-0 rounded-xl object-cover" />
            
              <p className="min-w-0 flex-1 truncate text-sm font-medium text-forest-800">
                {line.product.name}
              </p>
              <span className="text-xs text-ink-muted">Qty {line.qty}</span>
            </li>
          )}
        </ul>
      </div>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <Link to="/profile" className="flex-1">
          <Button fullWidth variant="secondary">
            All orders
          </Button>
        </Link>
        <Link to="/contact" className="flex-1">
          <Button fullWidth variant="ghost">
            Need help with this order?
          </Button>
        </Link>
      </div>
    </div>);

}
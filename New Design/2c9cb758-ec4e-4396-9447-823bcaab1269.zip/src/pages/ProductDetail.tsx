import React from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  CheckIcon,
  HeartIcon,
  LeafIcon,
  MinusIcon,
  PlusIcon,
  RotateCcwIcon,
  ShieldCheckIcon,
  ShoppingBagIcon,
  TruckIcon } from
'lucide-react';
import { getProduct, products } from '../data/products';
import { categoryLabel } from '../data/site';
import { Button } from '../components/ui/Button';
import { Rating } from '../components/ui/Rating';
import { ProductCard } from '../components/product/ProductCard';
import { useStore } from '../contexts/StoreContext';
import { cn, discountPercent, formatPrice } from '../utils/format';
import { NotFound } from './NotFound';

const perks = [
{ Icon: TruckIcon, label: 'Free delivery over ₹1,500' },
{ Icon: RotateCcwIcon, label: '30-day returns' },
{ Icon: ShieldCheckIcon, label: '2-year stitching warranty' },
{ Icon: LeafIcon, label: 'Plastic-free packaging' }];


export function ProductDetail() {
  const { id } = useParams();
  const product = id ? getProduct(id) : undefined;
  const { addToCart, toggleWishlist, isWishlisted, openCart } = useStore();
  const [qty, setQty] = React.useState(1);
  const [adding, setAdding] = React.useState(false);
  const [added, setAdded] = React.useState(false);

  if (!product) return <NotFound />;

  const off = discountPercent(product.price, product.compareAt);
  const saved = isWishlisted(product.id);
  const related = products.
  filter((p) => p.id !== product.id && p.category === product.category).
  concat(products.filter((p) => p.id !== product.id && p.category !== product.category)).
  slice(0, 4);

  const handleAdd = () => {
    setAdding(true);
    window.setTimeout(() => {
      setAdding(false);
      setAdded(true);
      addToCart(product, qty);
      window.setTimeout(() => setAdded(false), 1800);
    }, 550);
  };

  return (
    <div className="mx-auto max-w-[1240px] px-5 pb-16 pt-6 sm:px-8 sm:pt-10">
      <nav aria-label="Breadcrumb" className="text-[13px] text-ink-muted">
        <ol className="flex flex-wrap items-center gap-1.5">
          <li>
            <Link to="/" className="hover:text-forest-700">Home</Link>
          </li>
          <li aria-hidden="true">/</li>
          <li>
            <Link to="/products" className="hover:text-forest-700">Products</Link>
          </li>
          <li aria-hidden="true">/</li>
          <li className="text-ink-soft">{product.name}</li>
        </ol>
      </nav>

      <div className="mt-6 grid gap-10 lg:grid-cols-[1.05fr_1fr] lg:gap-14">
        <div>
          <div className="overflow-hidden rounded-5xl border border-ink-line/70 bg-sand-50">
            <img
              src={product.image}
              alt={product.name}
              className="aspect-square w-full object-cover" />
            
          </div>
          <ul className="mt-4 grid grid-cols-4 gap-3">
            {[0, 1, 2, 3].map((i) =>
            <li key={i}>
                <div
                className={cn(
                  'overflow-hidden rounded-2xl border bg-sand-50',
                  i === 0 ? 'border-forest-500' : 'border-ink-line/70'
                )}>
                
                  <img
                  src={product.image}
                  alt=""
                  className="aspect-square w-full object-cover"
                  style={{ objectPosition: `${20 + i * 20}% center` }} />
                
                </div>
              </li>
            )}
          </ul>
        </div>

        <div className="lg:pt-4">
          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold uppercase tracking-[0.14em] text-forest-500">
              {categoryLabel[product.category]}
            </span>
            {product.inStock ?
            <span className="inline-flex items-center gap-1.5 rounded-full bg-forest-50 px-2.5 py-1 text-[11px] font-medium text-forest-700">
                <span className="h-1.5 w-1.5 rounded-full bg-forest-500" />
                In stock
              </span> :

            <span className="rounded-full bg-clay/10 px-2.5 py-1 text-[11px] font-medium text-clay">
                Out of stock
              </span>
            }
          </div>

          <h1 className="mt-3 font-display text-4xl leading-[1.08] tracking-[-0.025em] text-forest-800 sm:text-[44px]">
            {product.name}
          </h1>
          <p className="mt-2 text-[15px] text-ink-muted">{product.tagline}</p>
          <Rating value={product.rating} reviews={product.reviews} size="md" className="mt-4" />

          <div className="mt-6 flex items-baseline gap-3">
            <span className="font-display text-[32px] leading-none text-forest-800">
              {formatPrice(product.price)}
            </span>
            {product.compareAt &&
            <span className="text-base text-ink-muted line-through">
                {formatPrice(product.compareAt)}
              </span>
            }
            {off !== null &&
            <span className="rounded-full bg-clay/10 px-2.5 py-1 text-xs font-semibold text-clay">
                Save {off}%
              </span>
            }
          </div>

          <p className="mt-6 text-[15px] leading-relaxed text-ink-soft">
            {product.description}
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1 rounded-full border border-ink-line bg-white p-1">
              <button
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                aria-label="Decrease quantity"
                className="grid h-9 w-9 place-items-center rounded-full text-ink-soft transition-colors duration-150 ease-premium hover:bg-sand-100">
                
                <MinusIcon className="h-4 w-4" aria-hidden="true" />
              </button>
              <span className="w-8 text-center text-sm font-semibold tabular-nums text-ink">
                {qty}
              </span>
              <button
                onClick={() => setQty((q) => Math.min(20, q + 1))}
                aria-label="Increase quantity"
                className="grid h-9 w-9 place-items-center rounded-full text-ink-soft transition-colors duration-150 ease-premium hover:bg-sand-100">
                
                <PlusIcon className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            <Button
              size="lg"
              loading={adding}
              disabled={!product.inStock}
              onClick={handleAdd}
              icon={
              added ?
              <CheckIcon className="h-4 w-4" aria-hidden="true" /> :
              !adding ?
              <ShoppingBagIcon className="h-4 w-4" aria-hidden="true" /> :
              undefined
              }
              className="flex-1 sm:flex-none">
              
              {added ? 'Added to cart' : product.inStock ? 'Add to cart' : 'Out of stock'}
            </Button>

            <Button
              size="lg"
              variant="secondary"
              disabled={!product.inStock}
              onClick={() => {
                addToCart(product, qty);
                openCart();
              }}>
              
              Buy now
            </Button>

            <button
              onClick={() => toggleWishlist(product)}
              aria-label={saved ? 'Remove from wishlist' : 'Save to wishlist'}
              aria-pressed={saved}
              className="grid h-[52px] w-[52px] shrink-0 place-items-center rounded-full border border-ink-line bg-white transition-[border-color,transform] duration-200 ease-premium hover:border-clay/40 active:scale-90">
              
              <HeartIcon
                className={cn('h-5 w-5', saved ? 'fill-clay text-clay' : 'text-forest-800')}
                aria-hidden="true" />
              
            </button>
          </div>

          <ul className="mt-8 grid grid-cols-2 gap-3">
            {perks.map(({ Icon, label }) =>
            <li
              key={label}
              className="flex items-center gap-2.5 rounded-2xl border border-ink-line/70 bg-white px-3.5 py-3 text-[13px] text-ink-soft">
              
                <Icon className="h-4 w-4 shrink-0 text-forest-500" aria-hidden="true" />
                {label}
              </li>
            )}
          </ul>

          <div className="mt-8 rounded-4xl border border-ink-line/70 bg-white p-6">
            <h2 className="text-sm font-semibold uppercase tracking-[0.14em] text-ink-muted">
              Specifications
            </h2>
            <dl className="mt-4 divide-y divide-ink-line">
              {product.specs.map((spec) =>
              <div key={spec.label} className="flex justify-between gap-6 py-3 text-sm">
                  <dt className="text-ink-soft">{spec.label}</dt>
                  <dd className="text-right font-medium text-ink">{spec.value}</dd>
                </div>
              )}
            </dl>
          </div>
        </div>
      </div>

      <section className="mt-20">
        <h2 className="font-display text-3xl tracking-[-0.02em] text-forest-800">
          You might also carry
        </h2>
        <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {related.map((p) =>
          <li key={p.id} className="h-full">
              <ProductCard product={p} />
            </li>
          )}
        </ul>
      </section>
    </div>);

}
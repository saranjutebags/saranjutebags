import React from 'react';
import { Link } from 'react-router-dom';
import { HeartIcon } from 'lucide-react';
import { products } from '../data/products';
import { useStore } from '../contexts/StoreContext';
import { ProductCard } from '../components/product/ProductCard';
import { Button } from '../components/ui/Button';

export function Wishlist() {
  const { wishlist } = useStore();
  const saved = products.filter((p) => wishlist.includes(p.id));

  return (
    <div className="mx-auto max-w-[1240px] px-5 pb-16 pt-8 sm:px-8 sm:pt-12">
      <header className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-forest-500">
          Saved
        </p>
        <h1 className="mt-3 font-display text-4xl leading-[1.1] tracking-[-0.025em] text-forest-800 sm:text-[46px]">
          Your wishlist
        </h1>
        <p className="mt-3 text-[15px] text-ink-soft">
          {saved.length === 0 ?
          'Nothing saved yet.' :
          `${saved.length} ${saved.length === 1 ? 'bag' : 'bags'} waiting for you.`}
        </p>
      </header>

      {saved.length === 0 ?
      <div className="mt-10 rounded-4xl border border-dashed border-ink-line bg-white/60 px-6 py-20 text-center">
          <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-sand-100">
            <HeartIcon className="h-7 w-7 text-sand-600" aria-hidden="true" />
          </span>
          <h2 className="mt-5 font-display text-xl text-forest-800">
            Tap the heart on any bag
          </h2>
          <p className="mx-auto mt-2 max-w-sm text-sm text-ink-soft">
            Saved bags stay here so you can compare before ordering.
          </p>
          <Link to="/products" className="mt-6 inline-block">
            <Button>Browse products</Button>
          </Link>
        </div> :

      <ul className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {saved.map((p) =>
        <li key={p.id} className="h-full">
              <ProductCard product={p} />
            </li>
        )}
        </ul>
      }
    </div>);

}
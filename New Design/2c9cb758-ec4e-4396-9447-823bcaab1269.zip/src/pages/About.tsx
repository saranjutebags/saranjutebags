import React from 'react';
import { Link } from 'react-router-dom';
import { heroImage, impactStats } from '../data/site';
import { Button } from '../components/ui/Button';
import { Reveal } from '../components/ui/Reveal';

const chapters = [
{
  title: 'A mill, not a marketplace',
  body: 'We buy raw jute directly from a 1,400-family co-operative in West Bengal and weave in our own unit. No middle layer means fair farm-gate prices and full traceability on every batch.'
},
{
  title: 'Built to be used, not admired',
  body: 'Every style is load-tested to 15 kg and washed twice before it goes into the catalogue. If a handle fails within two years, we replace the bag.'
},
{
  title: 'Plastic-free from end to end',
  body: 'Azo-free dyes, cotton thread, kraft packaging and paper tape. There is no plastic in the product or the parcel.'
}];


export function About() {
  return (
    <div className="pb-16">
      <section className="mx-auto max-w-[1240px] px-5 pt-10 sm:px-8 sm:pt-14">
        <div className="grid items-center gap-10 lg:grid-cols-[1.05fr_1fr] lg:gap-16">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-forest-500">
              About Saran
            </p>
            <h1 className="mt-4 font-display text-[42px] leading-[1.08] tracking-[-0.03em] text-forest-800 sm:text-[54px]">
              Started in a jute mill.
              <br />
              Still run like one.
            </h1>
            <p className="mt-6 max-w-lg text-[17px] leading-relaxed text-ink-soft">
              Saran began in 2019 when three mill workers decided the fibre they
              spun for export deserved a domestic brand of its own. Six years on
              we ship to 240 cities and still weave every bag ourselves.
            </p>
            <Link to="/products" className="mt-8 inline-block">
              <Button size="lg">Explore collection</Button>
            </Link>
          </div>
          <div className="overflow-hidden rounded-5xl border border-white/70 shadow-lift">
            <img
              src={heroImage}
              alt="A Saran jute tote in natural daylight"
              className="aspect-[4/5] w-full object-cover" />
            
          </div>
        </div>
      </section>

      <section className="mx-auto mt-20 max-w-[1240px] px-5 sm:px-8">
        <ul className="grid gap-4 lg:grid-cols-3">
          {chapters.map((chapter, i) =>
          <Reveal as="li" key={chapter.title} delay={i * 0.06} className="h-full">
              <article className="flex h-full flex-col rounded-4xl border border-ink-line/70 bg-white p-6 shadow-soft">
                <span className="font-display text-2xl text-sand-400">
                  0{i + 1}
                </span>
                <h2 className="mt-4 font-display text-xl leading-snug text-forest-800">
                  {chapter.title}
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-ink-soft">
                  {chapter.body}
                </p>
              </article>
            </Reveal>
          )}
        </ul>
      </section>

      <section className="mx-auto mt-16 max-w-[1240px] px-5 sm:px-8">
        <div className="rounded-5xl bg-forest-800 px-6 py-12 sm:px-12">
          <h2 className="font-display text-3xl tracking-[-0.02em] text-white">
            Where we are, in numbers
          </h2>
          <dl className="mt-10 grid grid-cols-2 gap-8 lg:grid-cols-4">
            {impactStats.map((stat) =>
            <div key={stat.label}>
                <dt className="sr-only">{stat.label}</dt>
                <dd>
                  <span className="block font-display text-[34px] leading-none text-white">
                    {stat.value}
                  </span>
                  <span className="mt-2 block text-sm text-sand-100">{stat.label}</span>
                  <span className="mt-0.5 block text-xs text-sand-200/70">
                    {stat.detail}
                  </span>
                </dd>
              </div>
            )}
          </dl>
        </div>
      </section>
    </div>);

}
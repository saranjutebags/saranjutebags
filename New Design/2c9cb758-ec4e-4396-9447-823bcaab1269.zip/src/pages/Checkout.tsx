import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeftIcon,
  CreditCardIcon,
  LockIcon,
  ShoppingBagIcon,
  WalletIcon } from
'lucide-react';
import { useStore } from '../contexts/StoreContext';
import { Button } from '../components/ui/Button';
import { cn, formatPrice } from '../utils/format';

interface Fields {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  pincode: string;
}

const emptyFields: Fields = {
  name: '',
  email: '',
  phone: '',
  address: '',
  city: '',
  pincode: ''
};

const labels: Record<keyof Fields, string> = {
  name: 'Full name',
  email: 'Email address',
  phone: 'Phone number',
  address: 'Street address',
  city: 'City',
  pincode: 'PIN code'
};

export function Checkout() {
  const { cart, cartSubtotal, placeOrder, pushToast } = useStore();
  const navigate = useNavigate();
  const [fields, setFields] = React.useState<Fields>(emptyFields);
  const [errors, setErrors] = React.useState<Partial<Record<keyof Fields, string>>>({});
  const [payment, setPayment] = React.useState<'upi' | 'card' | 'cod'>('upi');
  const [submitting, setSubmitting] = React.useState(false);

  const shipping = cartSubtotal >= 1500 || cartSubtotal === 0 ? 0 : 79;
  const total = cartSubtotal + shipping;

  const validate = () => {
    const next: Partial<Record<keyof Fields, string>> = {};
    (Object.keys(fields) as (keyof Fields)[]).forEach((key) => {
      if (!fields[key].trim()) next[key] = `${labels[key]} is required`;
    });
    if (fields.email && !/^\S+@\S+\.\S+$/.test(fields.email))
    next.email = 'Enter a valid email address';
    if (fields.phone && fields.phone.replace(/\D/g, '').length < 10)
    next.phone = 'Enter a 10-digit phone number';
    if (fields.pincode && fields.pincode.replace(/\D/g, '').length !== 6)
    next.pincode = 'PIN code must be 6 digits';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      pushToast({
        title: 'Check your details',
        description: 'Some required fields need attention.',
        tone: 'error'
      });
      return;
    }
    setSubmitting(true);
    window.setTimeout(() => {
      const order = placeOrder(
        `${fields.address}, ${fields.city} ${fields.pincode}`
      );
      setSubmitting(false);
      pushToast({ title: 'Order placed', description: order.id, tone: 'success' });
      navigate(`/order/${order.id}`);
    }, 1100);
  };

  if (cart.length === 0) {
    return (
      <div className="mx-auto max-w-md px-5 py-24 text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-sand-100">
          <ShoppingBagIcon className="h-7 w-7 text-sand-600" aria-hidden="true" />
        </span>
        <h1 className="mt-5 font-display text-3xl tracking-[-0.02em] text-forest-800">
          Nothing to check out
        </h1>
        <p className="mt-3 text-[15px] text-ink-soft">
          Add a bag to your cart and the checkout will open right here.
        </p>
        <Link to="/products" className="mt-7 inline-block">
          <Button size="lg">Shop now</Button>
        </Link>
      </div>);

  }

  const field = (key: keyof Fields, type = 'text', span = false) =>
  <div className={span ? 'sm:col-span-2' : ''}>
      <label htmlFor={key} className="block text-[13px] font-medium text-ink-soft">
        {labels[key]}
      </label>
      <input
      id={key}
      type={type}
      value={fields[key]}
      onChange={(e) => setFields((f) => ({ ...f, [key]: e.target.value }))}
      aria-invalid={Boolean(errors[key])}
      aria-describedby={errors[key] ? `${key}-error` : undefined}
      className={cn(
        'mt-1.5 h-11 w-full rounded-2xl border bg-white px-3.5 text-sm text-ink',
        'transition-colors duration-200 ease-premium placeholder:text-ink-muted',
        'focus:outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1',
        errors[key] ?
        'border-clay focus-visible:outline-clay' :
        'border-ink-line focus-visible:outline-forest-500'
      )} />
    
      {errors[key] &&
    <p id={`${key}-error`} className="mt-1.5 text-xs text-clay">
          {errors[key]}
        </p>
    }
    </div>;


  return (
    <div className="mx-auto max-w-[1100px] px-5 pb-16 pt-8 sm:px-8 sm:pt-12">
      <Link
        to="/products"
        className="inline-flex items-center gap-2 text-[13px] font-medium text-ink-soft hover:text-forest-700">
        
        <ArrowLeftIcon className="h-4 w-4" aria-hidden="true" />
        Continue shopping
      </Link>

      <h1 className="mt-5 font-display text-4xl tracking-[-0.025em] text-forest-800 sm:text-[46px]">
        Checkout
      </h1>

      <form onSubmit={submit} className="mt-9 grid gap-6 lg:grid-cols-[1fr_360px] lg:gap-8">
        <div className="space-y-5">
          <section className="rounded-4xl border border-ink-line/70 bg-white p-6 shadow-soft">
            <h2 className="font-display text-xl text-forest-800">Delivery details</h2>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              {field('name', 'text', true)}
              {field('email', 'email')}
              {field('phone', 'tel')}
              {field('address', 'text', true)}
              {field('city')}
              {field('pincode')}
            </div>
          </section>

          <section className="rounded-4xl border border-ink-line/70 bg-white p-6 shadow-soft">
            <h2 className="font-display text-xl text-forest-800">Payment</h2>
            <fieldset className="mt-5 space-y-2.5">
              <legend className="sr-only">Payment method</legend>
              {[
              { key: 'upi' as const, label: 'UPI', hint: 'Pay via any UPI app', Icon: WalletIcon },
              { key: 'card' as const, label: 'Card', hint: 'Visa, Mastercard, RuPay', Icon: CreditCardIcon },
              { key: 'cod' as const, label: 'Cash on delivery', hint: '₹20 handling fee waived', Icon: ShoppingBagIcon }].
              map((option) =>
              <label
                key={option.key}
                className={cn(
                  'flex cursor-pointer items-center gap-3.5 rounded-2xl border p-4',
                  'transition-[border-color,background-color] duration-200 ease-premium',
                  payment === option.key ?
                  'border-forest-500 bg-forest-50/70' :
                  'border-ink-line hover:border-forest-200'
                )}>
                
                  <input
                  type="radio"
                  name="payment"
                  value={option.key}
                  checked={payment === option.key}
                  onChange={() => setPayment(option.key)}
                  className="h-4 w-4 border-ink-line text-forest-700 focus:ring-forest-500" />
                
                  <option.Icon className="h-5 w-5 text-forest-500" aria-hidden="true" />
                  <span className="min-w-0">
                    <span className="block text-sm font-medium text-forest-800">
                      {option.label}
                    </span>
                    <span className="block text-xs text-ink-muted">{option.hint}</span>
                  </span>
                </label>
              )}
            </fieldset>
          </section>
        </div>

        <aside className="lg:sticky lg:top-28 lg:self-start">
          <div className="rounded-4xl border border-ink-line/70 bg-white p-6 shadow-soft">
            <h2 className="font-display text-xl text-forest-800">Order summary</h2>
            <ul className="mt-5 space-y-3.5">
              {cart.map((line) =>
              <li key={line.product.id} className="flex items-center gap-3">
                  <div className="relative shrink-0">
                    <img
                    src={line.product.image}
                    alt=""
                    className="h-14 w-14 rounded-2xl object-cover" />
                  
                    <span className="absolute -right-1.5 -top-1.5 grid h-5 min-w-[20px] place-items-center rounded-full bg-forest-700 px-1 text-[10px] font-bold text-sand-50">
                      {line.qty}
                    </span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-forest-800">
                      {line.product.name}
                    </p>
                    <p className="text-xs text-ink-muted">{line.product.tagline}</p>
                  </div>
                  <span className="text-sm font-semibold text-forest-800">
                    {formatPrice(line.product.price * line.qty)}
                  </span>
                </li>
              )}
            </ul>

            <dl className="mt-6 space-y-2.5 border-t border-ink-line pt-5 text-sm">
              <div className="flex justify-between">
                <dt className="text-ink-soft">Subtotal</dt>
                <dd className="text-ink">{formatPrice(cartSubtotal)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-ink-soft">Shipping</dt>
                <dd className={shipping === 0 ? 'text-forest-500' : 'text-ink'}>
                  {shipping === 0 ? 'Free' : formatPrice(shipping)}
                </dd>
              </div>
              <div className="flex justify-between border-t border-ink-line pt-3 text-base">
                <dt className="font-semibold text-forest-800">Total</dt>
                <dd className="font-semibold text-forest-800">{formatPrice(total)}</dd>
              </div>
            </dl>

            <motion.div whileTap={{ scale: 0.99 }}>
              <Button
                type="submit"
                size="lg"
                fullWidth
                loading={submitting}
                className="mt-6"
                icon={!submitting ? <LockIcon className="h-4 w-4" aria-hidden="true" /> : undefined}>
                
                {submitting ? 'Placing order…' : `Place order · ${formatPrice(total)}`}
              </Button>
            </motion.div>
            <p className="mt-3 text-center text-xs text-ink-muted">
              Encrypted payment. You can cancel free within 12 hours.
            </p>
          </div>
        </aside>
      </form>
    </div>);

}
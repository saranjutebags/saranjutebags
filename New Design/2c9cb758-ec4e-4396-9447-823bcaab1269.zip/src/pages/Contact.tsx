import React from 'react';
import { CheckCircle2Icon, MailIcon, MapPinIcon, PhoneIcon } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { useStore } from '../contexts/StoreContext';
import { cn } from '../utils/format';

export function Contact() {
  const { pushToast } = useStore();
  const [values, setValues] = React.useState({
    name: '',
    email: '',
    quantity: '',
    message: ''
  });
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [sending, setSending] = React.useState(false);
  const [sent, setSent] = React.useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!values.name.trim()) next.name = 'Please tell us your name';
    if (!/^\S+@\S+\.\S+$/.test(values.email)) next.email = 'Enter a valid email address';
    if (!values.message.trim()) next.message = 'Add a short brief so we can quote';
    setErrors(next);
    if (Object.keys(next).length > 0) {
      pushToast({ title: 'Check the form', description: 'A few fields need attention.', tone: 'error' });
      return;
    }
    setSending(true);
    window.setTimeout(() => {
      setSending(false);
      setSent(true);
      pushToast({
        title: 'Enquiry sent',
        description: 'We reply within one working day.',
        tone: 'success'
      });
    }, 1000);
  };

  const inputClass = (key: string) =>
  cn(
    'mt-1.5 w-full rounded-2xl border bg-white px-3.5 py-2.5 text-sm text-ink',
    'transition-colors duration-200 ease-premium placeholder:text-ink-muted focus:outline-none',
    'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-1',
    errors[key] ?
    'border-clay focus-visible:outline-clay' :
    'border-ink-line focus-visible:outline-forest-500'
  );

  return (
    <div className="mx-auto max-w-[1100px] px-5 pb-16 pt-8 sm:px-8 sm:pt-12">
      <header className="max-w-2xl">
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-forest-500">
          Contact
        </p>
        <h1 className="mt-3 font-display text-4xl leading-[1.1] tracking-[-0.025em] text-forest-800 sm:text-[46px]">
          Talk to the people who weave them
        </h1>
        <p className="mt-3 text-[15px] leading-relaxed text-ink-soft">
          Bulk quotes, custom branding, or a question about an order — we answer
          within one working day.
        </p>
      </header>

      <div className="mt-10 grid gap-6 lg:grid-cols-[1fr_320px] lg:gap-8">
        <section className="rounded-4xl border border-ink-line/70 bg-white p-6 shadow-soft sm:p-8">
          {sent ?
          <div className="flex flex-col items-center py-12 text-center">
              <CheckCircle2Icon className="h-12 w-12 text-forest-500" aria-hidden="true" />
              <h2 className="mt-5 font-display text-2xl text-forest-800">
                Enquiry received
              </h2>
              <p className="mt-2 max-w-sm text-sm text-ink-soft">
                Thanks {values.name.split(' ')[0]} — a member of the bulk team will
                email you a quote and digital proof shortly.
              </p>
              <Button
              variant="secondary"
              className="mt-6"
              onClick={() => {
                setSent(false);
                setValues({ name: '', email: '', quantity: '', message: '' });
              }}>
              
                Send another enquiry
              </Button>
            </div> :

          <form onSubmit={submit} noValidate>
              <h2 className="font-display text-xl text-forest-800">Request a quote</h2>
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <div>
                  <label htmlFor="c-name" className="text-[13px] font-medium text-ink-soft">
                    Your name
                  </label>
                  <input
                  id="c-name"
                  value={values.name}
                  onChange={(e) => setValues((v) => ({ ...v, name: e.target.value }))}
                  className={inputClass('name')}
                  aria-invalid={Boolean(errors.name)} />
                
                  {errors.name && <p className="mt-1.5 text-xs text-clay">{errors.name}</p>}
                </div>
                <div>
                  <label htmlFor="c-email" className="text-[13px] font-medium text-ink-soft">
                    Email
                  </label>
                  <input
                  id="c-email"
                  type="email"
                  value={values.email}
                  onChange={(e) => setValues((v) => ({ ...v, email: e.target.value }))}
                  className={inputClass('email')}
                  aria-invalid={Boolean(errors.email)} />
                
                  {errors.email && <p className="mt-1.5 text-xs text-clay">{errors.email}</p>}
                </div>
                <div className="sm:col-span-2">
                  <label htmlFor="c-qty" className="text-[13px] font-medium text-ink-soft">
                    Estimated quantity (optional)
                  </label>
                  <input
                  id="c-qty"
                  value={values.quantity}
                  onChange={(e) => setValues((v) => ({ ...v, quantity: e.target.value }))}
                  placeholder="e.g. 500 units"
                  className={inputClass('quantity')} />
                
                </div>
                <div className="sm:col-span-2">
                  <label htmlFor="c-msg" className="text-[13px] font-medium text-ink-soft">
                    What do you need?
                  </label>
                  <textarea
                  id="c-msg"
                  rows={5}
                  value={values.message}
                  onChange={(e) => setValues((v) => ({ ...v, message: e.target.value }))}
                  className={inputClass('message')}
                  aria-invalid={Boolean(errors.message)} />
                
                  {errors.message &&
                <p className="mt-1.5 text-xs text-clay">{errors.message}</p>
                }
                </div>
              </div>
              <Button type="submit" size="lg" loading={sending} className="mt-6">
                {sending ? 'Sending…' : 'Contact us'}
              </Button>
            </form>
          }
        </section>

        <aside className="space-y-4">
          <div className="rounded-4xl border border-ink-line/70 bg-white p-6 shadow-soft">
            <h2 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-muted">
              Reach us directly
            </h2>
            <ul className="mt-4 space-y-4 text-sm">
              <li className="flex gap-3">
                <PhoneIcon className="mt-0.5 h-4 w-4 shrink-0 text-forest-500" aria-hidden="true" />
                <span>
                  <a href="tel:+913344220088" className="font-medium text-forest-800 hover:underline">
                    +91 33 4422 0088
                  </a>
                  <span className="block text-xs text-ink-muted">Mon–Sat, 9am–7pm IST</span>
                </span>
              </li>
              <li className="flex gap-3">
                <MailIcon className="mt-0.5 h-4 w-4 shrink-0 text-forest-500" aria-hidden="true" />
                <span>
                  <a
                    href="mailto:hello@saranjute.com"
                    className="font-medium text-forest-800 hover:underline">
                    
                    hello@saranjute.com
                  </a>
                  <span className="block text-xs text-ink-muted">Replies within 24 hours</span>
                </span>
              </li>
              <li className="flex gap-3">
                <MapPinIcon className="mt-0.5 h-4 w-4 shrink-0 text-forest-500" aria-hidden="true" />
                <span>
                  <span className="font-medium text-forest-800">Kolkata unit</span>
                  <span className="block text-xs text-ink-muted">
                    Unit 14, Jute Park Road, Kolkata 700088
                  </span>
                </span>
              </li>
            </ul>
          </div>

          <div className="rounded-4xl bg-forest-800 p-6 text-sand-100">
            <p className="font-display text-xl text-white">Bulk pricing tiers</p>
            <ul className="mt-4 space-y-2.5 text-sm">
              {[
              ['50–199 units', 'Base price'],
              ['200–499 units', '−9%'],
              ['500+ units', '−18%']].
              map(([tier, save]) =>
              <li key={tier} className="flex justify-between border-b border-white/10 pb-2.5 last:border-0">
                  <span className="text-sand-200/90">{tier}</span>
                  <span className="font-medium text-white">{save}</span>
                </li>
              )}
            </ul>
          </div>
        </aside>
      </div>
    </div>);

}
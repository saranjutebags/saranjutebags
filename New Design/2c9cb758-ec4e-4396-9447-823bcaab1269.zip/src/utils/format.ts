export const formatPrice = (value: number): string =>
`₹${value.toLocaleString('en-IN')}`;

export const discountPercent = (price: number, compareAt?: number): number | null => {
  if (!compareAt || compareAt <= price) return null;
  return Math.round((compareAt - price) / compareAt * 100);
};

export const cn = (...classes: (string | false | null | undefined)[]): string =>
classes.filter(Boolean).join(' ');
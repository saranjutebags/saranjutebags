import React from 'react';
import {
  BadgeIndianRupeeIcon,
  LeafIcon,
  PaletteIcon,
  ShieldCheckIcon,
  SproutIcon } from
'lucide-react';
import { whyChooseUs } from '../../data/site';
import { SectionHeading } from '../ui/SectionHeading';
import { Reveal } from '../ui/Reveal';

const iconMap = {
  eco: LeafIcon,
  durable: ShieldCheckIcon,
  custom: PaletteIcon,
  afford: BadgeIndianRupeeIcon,
  sustain: SproutIcon
};

export function WhyChooseUs() {
  return (
    <section className="mx-auto max-w-[1240px] px-5 py-16 sm:px-8 sm:py-20">
      <SectionHeading
        eyebrow="Why Saran"
        title="Five reasons buyers switch and stay"
        align="center" />
      

      <ul className="mt-10 grid gap-x-10 gap-y-8 sm:grid-cols-2 lg:grid-cols-3">
        {whyChooseUs.map((item, i) => {
          const Icon = iconMap[item.key as keyof typeof iconMap];
          return (
            <Reveal as="li" key={item.key} delay={i * 0.05}>
              <div className="flex gap-4">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-forest-50 text-forest-500">
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <div>
                  <h3 className="text-base font-semibold tracking-[-0.01em] text-forest-800">
                    {item.title}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">
                    {item.body}
                  </p>
                </div>
              </div>
            </Reveal>);

        })}
      </ul>
    </section>);

}
import React from 'react';
import { motion } from 'framer-motion';
import { impactStats, juteTexture } from '../../data/site';
import { Reveal } from '../ui/Reveal';

const lifecycle = [
{ year: 'Year 1', label: 'Grown', detail: 'Rain-fed jute, no irrigation or pesticide load.' },
{ year: 'Years 2–5', label: 'Carried', detail: 'Replaces ~700 single-use plastic bags.' },
{ year: 'Year 6', label: 'Returned', detail: '96% biodegraded within 12 months in soil.' }];


export function ImpactSection() {
  return (
    <section className="relative overflow-hidden bg-forest-800 py-16 text-sand-100 sm:py-24">
      <img
        src={juteTexture}
        alt=""
        aria-hidden="true"
        className="absolute inset-0 h-full w-full object-cover opacity-[0.14]" />
      
      <div className="relative mx-auto max-w-[1240px] px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.1fr] lg:gap-20">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-sand-400">
              Environmental impact
            </p>
            <h2 className="mt-3 font-display text-3xl leading-[1.12] tracking-[-0.02em] text-white sm:text-[40px]">
              A plastic bag lasts 500 years.
              <br />
              Ours lasts five, then disappears.
            </h2>
            <p className="mt-5 max-w-md text-[15px] leading-relaxed text-sand-200/90">
              We measure impact per bag, not per campaign. Here is what the
              co-op's output added up to across the last five years.
            </p>

            <dl className="mt-10 grid grid-cols-2 gap-x-8 gap-y-8">
              {impactStats.map((stat, i) =>
              <Reveal key={stat.label} delay={i * 0.06}>
                  <dt className="sr-only">{stat.label}</dt>
                  <dd>
                    <span className="block font-display text-[34px] leading-none tracking-[-0.02em] text-white">
                      {stat.value}
                    </span>
                    <span className="mt-2 block text-sm font-medium text-sand-100">
                      {stat.label}
                    </span>
                    <span className="mt-0.5 block text-xs text-sand-200/70">
                      {stat.detail}
                    </span>
                  </dd>
                </Reveal>
              )}
            </dl>
          </div>

          <div className="rounded-4xl border border-white/12 bg-white/[0.06] p-6 backdrop-blur-xl sm:p-8">
            <h3 className="text-sm font-semibold uppercase tracking-[0.14em] text-sand-400">
              Life of one Saran bag
            </h3>
            <ol className="mt-7 space-y-8">
              {lifecycle.map((step, i) =>
              <li key={step.label} className="relative flex gap-5">
                  {i < lifecycle.length - 1 &&
                <span
                  className="absolute left-[15px] top-9 h-[calc(100%+14px)] w-px bg-white/15"
                  aria-hidden="true" />

                }
                  <motion.span
                  initial={{ scale: 0.6, opacity: 0 }}
                  whileInView={{ scale: 1, opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.35, delay: i * 0.1, ease: [0.23, 1, 0.32, 1] }}
                  className="relative z-10 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-sand-100 font-display text-sm text-forest-800">
                  
                    {i + 1}
                  </motion.span>
                  <div>
                    <p className="text-[11px] font-medium uppercase tracking-[0.14em] text-sand-400">
                      {step.year}
                    </p>
                    <p className="mt-1 font-display text-xl text-white">{step.label}</p>
                    <p className="mt-1.5 text-sm leading-relaxed text-sand-200/85">
                      {step.detail}
                    </p>
                  </div>
                </li>
              )}
            </ol>

            <div className="mt-8 rounded-3xl border border-white/12 bg-forest-900/40 p-5">
              <div className="flex items-baseline justify-between text-sm">
                <span className="text-sand-200/85">Plastic avoided this year</span>
                <span className="font-semibold text-white">312,000 bags</span>
              </div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/10">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: '78%' }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.9, ease: [0.23, 1, 0.32, 1] }}
                  className="h-full rounded-full bg-sand-300" />
                
              </div>
              <p className="mt-2 text-xs text-sand-200/70">78% of our 400,000 target</p>
            </div>
          </div>
        </div>
      </div>
    </section>);

}
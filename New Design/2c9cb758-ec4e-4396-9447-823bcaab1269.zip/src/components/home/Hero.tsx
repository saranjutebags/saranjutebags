import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRightIcon, LeafIcon, RecycleIcon, TruckIcon } from 'lucide-react';
import { Button } from '../ui/Button';
import { heroImage } from '../../data/site';

const ease = [0.23, 1, 0.32, 1] as const;

const proof = [
{ Icon: LeafIcon, label: '100% biodegradable jute' },
{ Icon: RecycleIcon, label: '1.2M plastic bags displaced' },
{ Icon: TruckIcon, label: 'Free shipping over ₹1,500' }];


export function Hero() {
  return (
    <section className="relative overflow-hidden pb-16 pt-10 sm:pb-24 sm:pt-14">
      <div className="jute-grain pointer-events-none absolute inset-0 opacity-70" aria-hidden="true" />
      <div
        className="pointer-events-none absolute -right-24 top-10 h-[420px] w-[420px] rounded-full bg-forest-50"
        aria-hidden="true" />
      

      <div className="relative mx-auto grid max-w-[1240px] items-center gap-12 px-5 sm:px-8 lg:grid-cols-[1.05fr_1fr] lg:gap-16">
        <div>
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease }}
            className="inline-flex items-center gap-2 rounded-full border border-forest-100 bg-white/70 px-3.5 py-1.5 text-xs font-medium text-forest-700 backdrop-blur-md">
            
            <span className="h-1.5 w-1.5 rounded-full bg-forest-500" />
            Woven by a 1,400-family farmer co-op
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.06, ease }}
            className="mt-6 font-display text-[42px] leading-[1.05] tracking-[-0.03em] text-forest-800 sm:text-[58px] lg:text-[64px]">
            
            Carry something
            <br />
            the earth can
            <span className="relative ml-3 inline-block">
              <span className="relative z-10">take back.</span>
              <motion.span
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 0.6, delay: 0.5, ease }}
                style={{ transformOrigin: 'left' }}
                className="absolute inset-x-0 bottom-1.5 z-0 h-3 rounded-full bg-sand-200"
                aria-hidden="true" />
              
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.14, ease }}
            className="mt-6 max-w-lg text-[17px] leading-relaxed text-ink-soft">
            
            Every Saran bag replaces roughly 700 single-use plastic carriers over its
            life — then returns to soil within a year. Built strong enough that you
            actually keep using it.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2, ease }}
            className="mt-8 flex flex-wrap items-center gap-3">
            
            <Link to="/products">
              <Button
                size="lg"
                iconRight={<ArrowRightIcon className="h-4 w-4" aria-hidden="true" />}>
                
                Shop now
              </Button>
            </Link>
            <Link to="/about">
              <Button size="lg" variant="secondary">
                Our impact
              </Button>
            </Link>
          </motion.div>

          <motion.ul
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.3, ease }}
            className="mt-10 flex flex-wrap gap-x-7 gap-y-3 border-t border-ink-line pt-6">
            
            {proof.map(({ Icon, label }) =>
            <li key={label} className="flex items-center gap-2 text-[13px] text-ink-soft">
                <Icon className="h-4 w-4 text-forest-500" aria-hidden="true" />
                {label}
              </li>
            )}
          </motion.ul>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.1, ease }}
          className="relative">
          
          <div className="overflow-hidden rounded-5xl border border-white/70 shadow-lift">
            <img
              src={heroImage}
              alt="Natural jute tote bag with leather handles on a stone plinth"
              className="aspect-[4/5] w-full object-cover" />
            
          </div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.45, ease }}
            className="absolute -left-2 bottom-8 w-[210px] rounded-3xl border border-white/70 bg-white/75 p-4 shadow-glass backdrop-blur-2xl sm:-left-8">
            
            <p className="font-display text-3xl leading-none text-forest-800">700×</p>
            <p className="mt-1.5 text-[13px] leading-snug text-ink-soft">
              plastic bags replaced by a single Harbour tote
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.55, ease }}
            className="absolute -right-2 top-8 flex items-center gap-2 rounded-2xl border border-white/70 bg-white/75 px-3.5 py-2.5 shadow-glass backdrop-blur-2xl sm:-right-6">
            
            <LeafIcon className="h-4 w-4 text-forest-500" aria-hidden="true" />
            <span className="text-[13px] font-medium text-forest-800">
              Certified compostable
            </span>
          </motion.div>
        </motion.div>
      </div>
    </section>);

}
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRightIcon, PackageIcon } from 'lucide-react';
import { Button } from '../ui/Button';
import { Reveal } from '../ui/Reveal';
import { juteTexture } from '../../data/site';

export function PromoBanner() {
  return (
    <section className="mx-auto max-w-[1240px] px-5 py-16 sm:px-8 sm:py-20">
      <Reveal>
        <div className="relative overflow-hidden rounded-5xl border border-ink-line/70 bg-sand-100">
          <img
            src={juteTexture}
            alt=""
            aria-hidden="true"
            className="absolute inset-0 h-full w-full object-cover" />
          
          <div className="absolute inset-0 bg-sand-50/45" aria-hidden="true" />

          <div className="relative flex flex-col gap-8 p-6 sm:p-10 lg:flex-row lg:items-center lg:justify-between lg:p-12">
            <div className="max-w-xl rounded-4xl border border-white/70 bg-white/70 p-6 backdrop-blur-2xl sm:p-8">
              <span className="inline-flex items-center gap-2 rounded-full bg-forest-700 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.12em] text-sand-50">
                <PackageIcon className="h-3.5 w-3.5" aria-hidden="true" />
                Bulk & branding
              </span>
              <h2 className="mt-4 font-display text-3xl leading-[1.12] tracking-[-0.02em] text-forest-800 sm:text-[38px]">
                Your logo, woven in. From 50 units.
              </h2>
              <p className="mt-4 text-[15px] leading-relaxed text-ink-soft">
                Digital proof in 48 hours, production in 7–10 working days, and
                volume pricing that beats imported cotton at every tier.
              </p>
              <div className="mt-7 flex flex-wrap gap-3">
                <Link to="/contact">
                  <Button
                    size="lg"
                    iconRight={<ArrowRightIcon className="h-4 w-4" aria-hidden="true" />}>
                    
                    Request a quote
                  </Button>
                </Link>
                <Link to="/products?category=custom">
                  <Button size="lg" variant="glass">
                    Explore custom bags
                  </Button>
                </Link>
              </div>
            </div>

            <dl className="grid grid-cols-3 gap-4 lg:max-w-[280px] lg:grid-cols-1">
              {[
              { v: '48 hrs', l: 'Proof turnaround' },
              { v: '50', l: 'Minimum units' },
              { v: '18%', l: 'Saved at 500+' }].
              map((item) =>
              <div
                key={item.l}
                className="rounded-3xl border border-white/70 bg-white/70 p-4 text-center backdrop-blur-2xl lg:text-left">
                
                  <dt className="sr-only">{item.l}</dt>
                  <dd>
                    <span className="block font-display text-2xl text-forest-800">
                      {item.v}
                    </span>
                    <span className="mt-1 block text-xs text-ink-soft">{item.l}</span>
                  </dd>
                </div>
              )}
            </dl>
          </div>
        </div>
      </Reveal>
    </section>);

}
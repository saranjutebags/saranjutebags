import React from 'react';
import { QuoteIcon } from 'lucide-react';
import { testimonials } from '../../data/site';
import { SectionHeading } from '../ui/SectionHeading';
import { Rating } from '../ui/Rating';
import { Reveal } from '../ui/Reveal';

export function Testimonials() {
  return (
    <section className="mx-auto max-w-[1240px] px-5 py-16 sm:px-8 sm:py-20">
      <SectionHeading
        eyebrow="Customer stories"
        title="Retailers, offices and households"
        description="Verified reviews from buyers who reordered at least twice." />
      

      <ul className="mt-10 grid gap-4 lg:grid-cols-3">
        {testimonials.map((t, i) =>
        <Reveal as="li" key={t.id} delay={i * 0.06} className="h-full">
            <figure className="flex h-full flex-col rounded-4xl border border-ink-line/70 bg-white p-6 shadow-soft">
              <QuoteIcon
              className="h-6 w-6 shrink-0 text-sand-300"
              aria-hidden="true" />
            
              <blockquote className="mt-4 flex-1 text-[15px] leading-relaxed text-ink">
                “{t.quote}”
              </blockquote>
              <figcaption className="mt-6 flex items-center gap-3 border-t border-ink-line pt-5">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-forest-50 text-sm font-semibold text-forest-700">
                  {t.initials}
                </span>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-forest-800">{t.name}</p>
                  <p className="truncate text-xs text-ink-muted">{t.role}</p>
                </div>
                <Rating value={t.rating} className="ml-auto shrink-0" />
              </figcaption>
            </figure>
          </Reveal>
        )}
      </ul>
    </section>);

}
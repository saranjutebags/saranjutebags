import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRightIcon } from 'lucide-react';
import { categories } from '../../data/site';
import { SectionHeading } from '../ui/SectionHeading';
import { Reveal } from '../ui/Reveal';

export function CategoryGrid() {
  const [lead, ...rest] = categories;

  return (
    <section className="mx-auto max-w-[1240px] px-5 py-16 sm:px-8 sm:py-20">
      <SectionHeading
        eyebrow="Collections"
        title="Find the bag that fits the job"
        description="Five collections, each built around a different weight, weave and finish." />
      

      <div className="mt-10 grid gap-4 lg:grid-cols-3 lg:grid-rows-2">
        <Reveal className="lg:row-span-2">
          <Link
            to={`/products?category=${lead.slug}`}
            className="group relative flex h-full min-h-[320px] flex-col justify-end overflow-hidden rounded-4xl border border-ink-line/70 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-forest-500">
            
            <img
              src={lead.image}
              alt=""
              className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 ease-premium group-hover:scale-105" />
            
            <div className="absolute inset-0 bg-forest-900/25" aria-hidden="true" />
            <div className="relative m-3 rounded-3xl border border-white/60 bg-white/75 p-5 backdrop-blur-xl">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-2xl tracking-[-0.02em] text-forest-800">
                    {lead.name}
                  </h3>
                  <p className="mt-1.5 text-sm text-ink-soft">{lead.blurb}</p>
                </div>
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-forest-700 text-sand-50 transition-transform duration-300 ease-premium group-hover:-translate-y-0.5 group-hover:translate-x-0.5">
                  <ArrowUpRightIcon className="h-4 w-4" aria-hidden="true" />
                </span>
              </div>
              <p className="mt-4 text-xs font-medium uppercase tracking-[0.14em] text-forest-500">
                {lead.count} styles
              </p>
            </div>
          </Link>
        </Reveal>

        {rest.map((category, i) =>
        <Reveal key={category.slug} delay={0.06 * (i + 1)}>
            <Link
            to={`/products?category=${category.slug}`}
            className="group flex h-full items-center gap-4 overflow-hidden rounded-4xl border border-ink-line/70 bg-white p-3 shadow-soft transition-[box-shadow,border-color] duration-300 ease-premium hover:border-sand-300 hover:shadow-lift focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-forest-500">
            
              <div className="h-24 w-24 shrink-0 overflow-hidden rounded-3xl bg-sand-50">
                <img
                src={category.image}
                alt=""
                className="h-full w-full object-cover transition-transform duration-500 ease-premium group-hover:scale-110" />
              
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-base font-semibold tracking-[-0.01em] text-forest-800">
                  {category.name}
                </h3>
                <p className="mt-1 text-[13px] leading-relaxed text-ink-soft">
                  {category.blurb}
                </p>
                <p className="mt-2 text-[11px] font-medium uppercase tracking-[0.14em] text-ink-muted">
                  {category.count} styles
                </p>
              </div>
              <ArrowUpRightIcon
              className="mr-2 h-4 w-4 shrink-0 text-ink-muted transition-[transform,color] duration-300 ease-premium group-hover:-translate-y-0.5 group-hover:text-forest-500"
              aria-hidden="true" />
            
            </Link>
          </Reveal>
        )}
      </div>
    </section>);

}
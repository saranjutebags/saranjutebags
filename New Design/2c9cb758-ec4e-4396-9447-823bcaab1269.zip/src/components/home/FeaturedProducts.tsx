import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRightIcon } from 'lucide-react';
import { products } from '../../data/products';
import { ProductCard } from '../product/ProductCard';
import { ProductCardSkeleton } from '../ui/Skeleton';
import { SectionHeading } from '../ui/SectionHeading';
import { Button } from '../ui/Button';
import { Reveal } from '../ui/Reveal';

export function FeaturedProducts() {
  const [loading, setLoading] = React.useState(true);
  const featured = products.slice(0, 4);

  React.useEffect(() => {
    const t = window.setTimeout(() => setLoading(false), 700);
    return () => window.clearTimeout(t);
  }, []);

  return (
    <section className="py-16 sm:py-20">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8">
        <SectionHeading
          eyebrow="Featured"
          title="This month's most carried"
          description="Restocked weekly, shipped plastic-free in recycled kraft."
          action={
          <Link to="/products">
              <Button
              variant="secondary"
              iconRight={<ArrowRightIcon className="h-4 w-4" aria-hidden="true" />}>
              
                View all products
              </Button>
            </Link>
          } />
        
      </div>

      {loading ?
      <div className="mx-auto mt-10 grid max-w-[1240px] gap-4 px-5 sm:grid-cols-2 sm:px-8 lg:grid-cols-4">
          {featured.map((p) =>
        <ProductCardSkeleton key={p.id} />
        )}
        </div> :

      <>
          <ul className="no-scrollbar mt-10 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-2 sm:hidden">
            {featured.map((product) =>
          <li key={product.id} className="w-[78%] shrink-0 snap-start">
                <ProductCard product={product} />
              </li>
          )}
          </ul>

          <ul className="mx-auto mt-10 hidden max-w-[1240px] gap-4 px-5 sm:grid sm:grid-cols-2 sm:px-8 lg:grid-cols-4">
            {featured.map((product, i) =>
          <Reveal as="li" key={product.id} delay={i * 0.06} className="h-full">
                <ProductCard product={product} />
              </Reveal>
          )}
          </ul>
        </>
      }
    </section>);

}
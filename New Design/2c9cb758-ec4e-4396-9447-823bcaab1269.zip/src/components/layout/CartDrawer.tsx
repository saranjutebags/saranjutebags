import React from 'react';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowRightIcon,
  MinusIcon,
  PlusIcon,
  ShoppingBagIcon,
  Trash2Icon,
  TruckIcon,
  XIcon } from
'lucide-react';
import { useStore } from '../../contexts/StoreContext';
import { Button } from '../ui/Button';
import { formatPrice } from '../../utils/format';

const FREE_SHIPPING = 1500;

export function CartDrawer() {
  const {
    cartOpen,
    closeCart,
    cart,
    setQty,
    removeFromCart,
    cartSubtotal
  } = useStore();
  const navigate = useNavigate();

  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && closeCart();
    if (cartOpen) window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [cartOpen, closeCart]);

  const remaining = Math.max(0, FREE_SHIPPING - cartSubtotal);
  const progress = Math.min(100, cartSubtotal / FREE_SHIPPING * 100);

  return (
    <AnimatePresence>
      {cartOpen &&
      <div className="fixed inset-0 z-[75]">
          <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={closeCart}
          className="absolute inset-0 bg-forest-900/35 backdrop-blur-sm" />
        
          <motion.aside
          role="dialog"
          aria-modal="true"
          aria-label="Shopping cart"
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
          className="absolute right-0 top-0 flex h-full w-full max-w-md flex-col border-l border-white/60 bg-white/92 shadow-lift backdrop-blur-2xl">
          
            <header className="flex items-center justify-between border-b border-ink-line px-5 py-4">
              <div>
                <h2 className="font-display text-xl text-forest-800">Your cart</h2>
                <p className="text-xs text-ink-muted">
                  {cart.length === 0 ?
                'No items yet' :
                `${cart.length} ${cart.length === 1 ? 'item' : 'items'}`}
                </p>
              </div>
              <button
              onClick={closeCart}
              aria-label="Close cart"
              className="grid h-9 w-9 place-items-center rounded-full text-ink-soft transition-colors duration-150 ease-premium hover:bg-sand-100 hover:text-ink">
              
                <XIcon className="h-[18px] w-[18px]" aria-hidden="true" />
              </button>
            </header>

            {cart.length > 0 &&
          <div className="border-b border-ink-line bg-forest-50/60 px-5 py-3">
                <div className="flex items-center gap-2 text-[13px] text-forest-700">
                  <TruckIcon className="h-4 w-4 shrink-0" aria-hidden="true" />
                  {remaining > 0 ?
              <span>
                      Add <strong>{formatPrice(remaining)}</strong> for free shipping
                    </span> :

              <span className="font-medium">Free shipping unlocked</span>
              }
                </div>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-forest-100">
                  <motion.div
                className="h-full rounded-full bg-forest-500"
                initial={false}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }} />
              
                </div>
              </div>
          }

            <div className="flex-1 overflow-y-auto px-5 py-4">
              {cart.length === 0 ?
            <div className="flex h-full flex-col items-center justify-center text-center">
                  <span className="grid h-16 w-16 place-items-center rounded-full bg-sand-100">
                    <ShoppingBagIcon
                  className="h-7 w-7 text-sand-600"
                  aria-hidden="true" />
                
                  </span>
                  <h3 className="mt-4 font-display text-lg text-forest-800">
                    Your cart is empty
                  </h3>
                  <p className="mt-1 max-w-[240px] text-sm text-ink-soft">
                    Browse the collection and your picks will show up here.
                  </p>
                  <Button
                className="mt-5"
                variant="secondary"
                onClick={() => {
                  closeCart();
                  navigate('/products');
                }}>
                
                    Explore collection
                  </Button>
                </div> :

            <ul className="space-y-3">
                  <AnimatePresence initial={false}>
                    {cart.map((line) =>
                <motion.li
                  key={line.product.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: 24 }}
                  transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
                  className="flex gap-3 rounded-3xl border border-ink-line/80 bg-white p-3">
                  
                        <img
                    src={line.product.image}
                    alt=""
                    className="h-20 w-20 shrink-0 rounded-2xl object-cover" />
                  
                        <div className="min-w-0 flex-1">
                          <div className="flex items-start justify-between gap-2">
                            <h3 className="truncate text-sm font-semibold text-forest-800">
                              {line.product.name}
                            </h3>
                            <button
                        onClick={() => removeFromCart(line.product.id)}
                        aria-label={`Remove ${line.product.name}`}
                        className="shrink-0 rounded-full p-1 text-ink-muted transition-colors duration-150 ease-premium hover:bg-clay/10 hover:text-clay">
                        
                              <Trash2Icon className="h-4 w-4" aria-hidden="true" />
                            </button>
                          </div>
                          <p className="truncate text-xs text-ink-muted">
                            {line.product.tagline}
                          </p>
                          <div className="mt-2.5 flex items-center justify-between">
                            <div className="flex items-center gap-1 rounded-full border border-ink-line p-0.5">
                              <button
                          onClick={() => setQty(line.product.id, line.qty - 1)}
                          aria-label="Decrease quantity"
                          className="grid h-7 w-7 place-items-center rounded-full text-ink-soft transition-colors duration-150 ease-premium hover:bg-sand-100">
                          
                                <MinusIcon className="h-3.5 w-3.5" aria-hidden="true" />
                              </button>
                              <span className="w-6 text-center text-sm font-semibold tabular-nums text-ink">
                                {line.qty}
                              </span>
                              <button
                          onClick={() => setQty(line.product.id, line.qty + 1)}
                          aria-label="Increase quantity"
                          className="grid h-7 w-7 place-items-center rounded-full text-ink-soft transition-colors duration-150 ease-premium hover:bg-sand-100">
                          
                                <PlusIcon className="h-3.5 w-3.5" aria-hidden="true" />
                              </button>
                            </div>
                            <span className="text-sm font-semibold text-forest-800">
                              {formatPrice(line.product.price * line.qty)}
                            </span>
                          </div>
                        </div>
                      </motion.li>
                )}
                  </AnimatePresence>
                </ul>
            }
            </div>

            {cart.length > 0 &&
          <footer className="border-t border-ink-line bg-white/80 px-5 py-4">
                <div className="flex items-center justify-between text-sm text-ink-soft">
                  <span>Subtotal</span>
                  <span className="font-semibold text-forest-800">
                    {formatPrice(cartSubtotal)}
                  </span>
                </div>
                <p className="mt-1 text-xs text-ink-muted">
                  Taxes calculated at checkout.
                </p>
                <Button
              fullWidth
              size="lg"
              className="mt-4"
              iconRight={<ArrowRightIcon className="h-4 w-4" aria-hidden="true" />}
              onClick={() => {
                closeCart();
                navigate('/checkout');
              }}>
              
                  Checkout
                </Button>
              </footer>
          }
          </motion.aside>
        </div>
      }
    </AnimatePresence>);

}
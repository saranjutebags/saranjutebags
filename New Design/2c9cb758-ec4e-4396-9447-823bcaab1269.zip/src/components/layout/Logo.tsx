import React from 'react';
import { Link } from 'react-router-dom';

export function Logo({ compact = false }: {compact?: boolean;}) {
  return (
    <Link
      to="/"
      className="group flex items-center gap-2.5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-forest-500"
      aria-label="Saran Jute Bags — home">
      
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-forest-700 text-sand-50 transition-transform duration-300 ease-premium group-hover:rotate-[-6deg]">
        <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden="true" fill="none">
          <path
            d="M4.8 8.5h14.4l-1.3 11.2a1.6 1.6 0 0 1-1.6 1.4H7.7a1.6 1.6 0 0 1-1.6-1.4L4.8 8.5Z"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinejoin="round" />
          
          <path
            d="M8.8 8.5V6.6a3.2 3.2 0 0 1 6.4 0v1.9"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round" />
          
        </svg>
      </span>
      {!compact &&
      <span className="leading-none">
          <span className="block font-display text-[17px] tracking-[-0.015em] text-forest-800">
            Saran
          </span>
          <span className="block text-[10px] font-medium uppercase tracking-[0.22em] text-ink-muted">
            Jute Bags
          </span>
        </span>
      }
    </Link>);

}
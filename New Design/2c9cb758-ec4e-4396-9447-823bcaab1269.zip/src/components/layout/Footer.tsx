import React from 'react';
import { Link } from 'react-router-dom';
import {
  FacebookIcon,
  InstagramIcon,
  LinkedinIcon,
  MailIcon,
  MapPinIcon,
  PhoneIcon,
  TwitterIcon } from
'lucide-react';
import { footerLinks } from '../../data/site';

const socials = [
{ label: 'Instagram', Icon: InstagramIcon },
{ label: 'Facebook', Icon: FacebookIcon },
{ label: 'Twitter', Icon: TwitterIcon },
{ label: 'LinkedIn', Icon: LinkedinIcon }];


export function Footer() {
  return (
    <footer className="mt-24 bg-forest-800 text-sand-100">
      <div className="mx-auto max-w-[1240px] px-5 pb-10 pt-14 sm:px-8">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_repeat(4,1fr)]">
          <div className="max-w-sm">
            <div className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-sand-100 text-forest-800">
                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" aria-hidden="true">
                  <path
                    d="M4.8 8.5h14.4l-1.3 11.2a1.6 1.6 0 0 1-1.6 1.4H7.7a1.6 1.6 0 0 1-1.6-1.4L4.8 8.5Z"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinejoin="round" />
                  
                  <path
                    d="M8.8 8.5V6.6a3.2 3.2 0 0 1 6.4 0v1.9"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinecap="round" />
                  
                </svg>
              </span>
              <span className="font-display text-lg text-white">Saran Jute Bags</span>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-sand-200/90">
              Mill-direct jute bags woven by a 1,400-family farmer co-operative in
              West Bengal. Plastic-free since 2019.
            </p>
            <ul className="mt-6 space-y-2.5 text-sm text-sand-200/90">
              <li className="flex items-start gap-2.5">
                <MapPinIcon className="mt-0.5 h-4 w-4 shrink-0 text-sand-400" aria-hidden="true" />
                Unit 14, Jute Park Road, Kolkata 700088
              </li>
              <li className="flex items-center gap-2.5">
                <PhoneIcon className="h-4 w-4 shrink-0 text-sand-400" aria-hidden="true" />
                <a href="tel:+913344220088" className="hover:text-white">+91 33 4422 0088</a>
              </li>
              <li className="flex items-center gap-2.5">
                <MailIcon className="h-4 w-4 shrink-0 text-sand-400" aria-hidden="true" />
                <a href="mailto:hello@saranjute.com" className="hover:text-white">
                  hello@saranjute.com
                </a>
              </li>
            </ul>
          </div>

          {Object.entries(footerLinks).map(([heading, items]) =>
          <div key={heading}>
              <h3 className="text-[11px] font-semibold uppercase tracking-[0.16em] text-sand-400">
                {heading}
              </h3>
              <ul className="mt-4 space-y-2.5">
                {items.map((item) =>
              <li key={item}>
                    <Link
                  to={heading === 'Products' ? '/products' : '/contact'}
                  className="text-sm text-sand-200/90 underline-offset-4 transition-colors duration-200 ease-premium hover:text-white hover:underline">
                  
                      {item}
                    </Link>
                  </li>
              )}
              </ul>
            </div>
          )}
        </div>

        <div className="mt-12 flex flex-col gap-5 border-t border-white/10 pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-sand-200/70">
            © {new Date().getFullYear()} Saran Jute Bags Pvt. Ltd. All rights reserved.
          </p>
          <ul className="flex items-center gap-2">
            {socials.map(({ label, Icon }) =>
            <li key={label}>
                <a
                href="#"
                aria-label={label}
                className="grid h-9 w-9 place-items-center rounded-full border border-white/15 text-sand-200 transition-[background-color,color] duration-200 ease-premium hover:bg-white/10 hover:text-white">
                
                  <Icon className="h-4 w-4" aria-hidden="true" />
                </a>
              </li>
            )}
          </ul>
        </div>
      </div>
    </footer>);

}
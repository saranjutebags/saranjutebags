import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { HeartIcon, HomeIcon, ShoppingBagIcon, StoreIcon, UserIcon } from 'lucide-react';
import { useStore } from '../../contexts/StoreContext';
import { cn } from '../../utils/format';

const tabs = [
{ to: '/', label: 'Home', icon: HomeIcon, end: true },
{ to: '/products', label: 'Shop', icon: StoreIcon, end: false },
{ to: '/wishlist', label: 'Saved', icon: HeartIcon, end: false },
{ to: '/profile', label: 'Profile', icon: UserIcon, end: false }];


export function MobileTabBar() {
  const { cartCount, openCart } = useStore();
  const { pathname } = useLocation();
  const hidden = pathname === '/checkout';

  if (hidden) return null;

  return (
    <>
      <AnimatePresence>
        {cartCount > 0 &&
        <motion.button
          initial={{ opacity: 0, scale: 0.8, y: 12 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.85, y: 8 }}
          transition={{ duration: 0.24, ease: [0.23, 1, 0.32, 1] }}
          onClick={openCart}
          aria-label={`Open cart, ${cartCount} items`}
          className="fixed bottom-[88px] right-4 z-[60] grid h-14 w-14 place-items-center rounded-full bg-forest-700 text-sand-50 shadow-lift transition-transform duration-200 ease-premium active:scale-90 lg:bottom-6">
          
            <ShoppingBagIcon className="h-6 w-6" aria-hidden="true" />
            <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-[20px] place-items-center rounded-full border-2 border-canvas bg-clay px-1 text-[10px] font-bold text-white">
              {cartCount}
            </span>
          </motion.button>
        }
      </AnimatePresence>

      <nav
        aria-label="Mobile navigation"
        className="fixed inset-x-0 bottom-0 z-[55] border-t border-white/70 bg-white/85 pb-[env(safe-area-inset-bottom)] backdrop-blur-2xl lg:hidden">
        
        <ul className="mx-auto flex max-w-md items-stretch justify-between px-2">
          {tabs.map((tab) =>
          <li key={tab.to} className="flex-1">
              <NavLink
              to={tab.to}
              end={tab.end}
              className={({ isActive }) =>
              cn(
                'flex min-h-[60px] flex-col items-center justify-center gap-1 rounded-2xl py-2 text-[11px] font-medium',
                'transition-colors duration-200 ease-premium',
                isActive ? 'text-forest-700' : 'text-ink-muted'
              )
              }>
              
                {({ isActive }) =>
              <>
                    <tab.icon
                  className={cn('h-[22px] w-[22px]', isActive && 'stroke-[2.2]')}
                  aria-hidden="true" />
                
                    {tab.label}
                  </>
              }
              </NavLink>
            </li>
          )}
        </ul>
      </nav>
    </>);

}
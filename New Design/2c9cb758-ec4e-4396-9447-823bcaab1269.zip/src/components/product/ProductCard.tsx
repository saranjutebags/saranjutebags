import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { EyeIcon, HeartIcon, ShoppingBagIcon } from 'lucide-react';
import type { Product } from '../../types';
import { Button } from '../ui/Button';
import { Rating } from '../ui/Rating';
import { useStore } from '../../contexts/StoreContext';
import { cn, discountPercent, formatPrice } from '../../utils/format';

interface ProductCardProps {
  product: Product;
  className?: string;
}

export function ProductCard({ product, className }: ProductCardProps) {
  const { addToCart, toggleWishlist, isWishlisted, setQuickView } = useStore();
  const [adding, setAdding] = React.useState(false);
  const saved = isWishlisted(product.id);
  const off = discountPercent(product.price, product.compareAt);

  const handleAdd = () => {
    if (!product.inStock) return;
    setAdding(true);
    window.setTimeout(() => {
      setAdding(false);
      addToCart(product);
    }, 550);
  };

  return (
    <motion.article
      whileHover={{ y: -6 }}
      transition={{ duration: 0.28, ease: [0.23, 1, 0.32, 1] }}
      className={cn(
        'group flex h-full flex-col rounded-4xl border border-ink-line/80 bg-white p-3',
        'shadow-soft transition-[box-shadow,border-color] duration-300 ease-premium hover:border-sand-300 hover:shadow-lift',
        className
      )}>
      
      <div className="relative overflow-hidden rounded-3xl bg-sand-50">
        <Link
          to={`/products/${product.id}`}
          aria-label={`View ${product.name}`}
          className="block focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-[-4px] focus-visible:outline-forest-500">
          
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            className="aspect-[4/5] w-full object-cover transition-transform duration-500 ease-premium group-hover:scale-[1.06]" />
          
        </Link>

        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between p-3">
          <div className="flex flex-col gap-1.5">
            {product.badge &&
            <span className="pointer-events-auto rounded-full bg-forest-700 px-2.5 py-1 text-[11px] font-semibold tracking-wide text-sand-50">
                {product.badge}
              </span>
            }
            {off !== null &&
            <span className="pointer-events-auto rounded-full bg-white/80 px-2.5 py-1 text-[11px] font-semibold text-clay backdrop-blur-md">
                {off}% off
              </span>
            }
          </div>
          <button
            type="button"
            onClick={() => toggleWishlist(product)}
            aria-label={saved ? `Remove ${product.name} from wishlist` : `Save ${product.name} to wishlist`}
            aria-pressed={saved}
            className="pointer-events-auto grid h-9 w-9 place-items-center rounded-full border border-white/70 bg-white/70 backdrop-blur-md transition-[background-color,transform] duration-200 ease-premium hover:bg-white active:scale-90 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-forest-500">
            
            <HeartIcon
              className={cn(
                'h-[18px] w-[18px] transition-colors duration-200 ease-premium',
                saved ? 'fill-clay text-clay' : 'text-forest-800'
              )}
              aria-hidden="true" />
            
          </button>
        </div>

        {!product.inStock &&
        <div className="absolute inset-0 grid place-items-center bg-white/55 backdrop-blur-[2px]">
            <span className="rounded-full border border-white/70 bg-white/85 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.12em] text-ink-soft backdrop-blur-md">
              Out of stock
            </span>
          </div>
        }

        <div className="absolute inset-x-3 bottom-3 translate-y-3 opacity-0 transition-[opacity,transform] duration-300 ease-premium group-hover:translate-y-0 group-hover:opacity-100 focus-within:translate-y-0 focus-within:opacity-100">
          <Button
            variant="glass"
            size="sm"
            fullWidth
            icon={<EyeIcon className="h-4 w-4" aria-hidden="true" />}
            onClick={() => setQuickView(product)}>
            
            Quick view
          </Button>
        </div>
      </div>

      <div className="flex flex-1 flex-col px-2 pb-1 pt-4">
        <Rating value={product.rating} reviews={product.reviews} />
        <h3 className="mt-2 text-[17px] font-semibold leading-snug tracking-[-0.01em] text-forest-800">
          <Link
            to={`/products/${product.id}`}
            className="transition-colors duration-200 ease-premium hover:text-forest-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-forest-500">
            
            {product.name}
          </Link>
        </h3>
        <p className="mt-1.5 line-clamp-2 text-[13px] leading-relaxed text-ink-soft">
          {product.description}
        </p>

        <div className="mt-auto flex items-end justify-between gap-3 pt-4">
          <div>
            <p className="text-lg font-semibold tracking-[-0.02em] text-forest-800">
              {formatPrice(product.price)}
            </p>
            {product.compareAt &&
            <p className="text-[13px] text-ink-muted line-through">
                {formatPrice(product.compareAt)}
              </p>
            }
          </div>
          <Button
            size="sm"
            loading={adding}
            disabled={!product.inStock}
            onClick={handleAdd}
            icon={
            !adding ?
            <ShoppingBagIcon className="h-4 w-4" aria-hidden="true" /> :
            undefined
            }>
            
            {product.inStock ? 'Add to cart' : 'Sold out'}
          </Button>
        </div>
      </div>
    </motion.article>);

}
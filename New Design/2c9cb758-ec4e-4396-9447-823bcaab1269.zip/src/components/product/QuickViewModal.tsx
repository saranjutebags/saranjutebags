import React from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { HeartIcon, ShoppingBagIcon, XIcon } from 'lucide-react';
import { useStore } from '../../contexts/StoreContext';
import { Button } from '../ui/Button';
import { Rating } from '../ui/Rating';
import { categoryLabel } from '../../data/site';
import { cn, discountPercent, formatPrice } from '../../utils/format';

export function QuickViewModal() {
  const { quickView, setQuickView, addToCart, toggleWishlist, isWishlisted } =
  useStore();

  React.useEffect(() => {
    if (!quickView) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setQuickView(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [quickView, setQuickView]);

  const product = quickView;
  const off = product ? discountPercent(product.price, product.compareAt) : null;
  const saved = product ? isWishlisted(product.id) : false;

  return (
    <AnimatePresence>
      {product &&
      <div className="fixed inset-0 z-[70] flex items-end justify-center sm:items-center sm:p-6">
          <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={() => setQuickView(null)}
          className="absolute inset-0 bg-forest-900/35 backdrop-blur-sm" />
        
          <motion.div
          role="dialog"
          aria-modal="true"
          aria-label={`${product.name} quick view`}
          initial={{ opacity: 0, y: 24, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 16, scale: 0.98 }}
          transition={{ duration: 0.26, ease: [0.23, 1, 0.32, 1] }}
          className="relative max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-t-4xl border border-white/70 bg-white/90 shadow-lift backdrop-blur-2xl sm:rounded-4xl">
          
            <button
            onClick={() => setQuickView(null)}
            aria-label="Close quick view"
            className="absolute right-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-full border border-white/70 bg-white/80 text-forest-800 backdrop-blur-md transition-[background-color,transform] duration-200 ease-premium hover:bg-white active:scale-90">
            
              <XIcon className="h-4 w-4" aria-hidden="true" />
            </button>

            <div className="grid gap-0 sm:grid-cols-2">
              <div className="overflow-hidden bg-sand-50 sm:rounded-l-4xl">
                <img
                src={product.image}
                alt={product.name}
                className="h-full max-h-[300px] w-full object-cover sm:max-h-none" />
              
              </div>
              <div className="flex flex-col p-6 sm:p-7">
                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-forest-500">
                  {categoryLabel[product.category]}
                </p>
                <h2 className="mt-2 font-display text-2xl leading-tight tracking-[-0.02em] text-forest-800">
                  {product.name}
                </h2>
                <Rating
                value={product.rating}
                reviews={product.reviews}
                size="md"
                className="mt-3" />
              
                <p className="mt-4 text-sm leading-relaxed text-ink-soft">
                  {product.description}
                </p>

                <div className="mt-5 flex items-baseline gap-3">
                  <span className="font-display text-2xl text-forest-800">
                    {formatPrice(product.price)}
                  </span>
                  {product.compareAt &&
                <span className="text-sm text-ink-muted line-through">
                      {formatPrice(product.compareAt)}
                    </span>
                }
                  {off !== null &&
                <span className="rounded-full bg-clay/10 px-2 py-0.5 text-xs font-semibold text-clay">
                      Save {off}%
                    </span>
                }
                </div>

                <dl className="mt-5 grid grid-cols-2 gap-x-4 gap-y-3 border-t border-ink-line pt-5">
                  {product.specs.slice(0, 4).map((spec) =>
                <div key={spec.label}>
                      <dt className="text-[11px] uppercase tracking-[0.1em] text-ink-muted">
                        {spec.label}
                      </dt>
                      <dd className="mt-0.5 text-[13px] font-medium text-ink">
                        {spec.value}
                      </dd>
                    </div>
                )}
                </dl>

                <div className="mt-6 flex items-center gap-2.5">
                  <Button
                  fullWidth
                  disabled={!product.inStock}
                  icon={<ShoppingBagIcon className="h-4 w-4" aria-hidden="true" />}
                  onClick={() => {
                    addToCart(product);
                    setQuickView(null);
                  }}>
                  
                    {product.inStock ? 'Add to cart' : 'Out of stock'}
                  </Button>
                  <button
                  onClick={() => toggleWishlist(product)}
                  aria-label={saved ? 'Remove from wishlist' : 'Save to wishlist'}
                  aria-pressed={saved}
                  className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-ink-line bg-white transition-[background-color,transform,border-color] duration-200 ease-premium hover:border-clay/40 active:scale-90">
                  
                    <HeartIcon
                    className={cn(
                      'h-[18px] w-[18px]',
                      saved ? 'fill-clay text-clay' : 'text-forest-800'
                    )}
                    aria-hidden="true" />
                  
                  </button>
                </div>
                <Link
                to={`/products/${product.id}`}
                onClick={() => setQuickView(null)}
                className="mt-3 text-center text-[13px] font-medium text-forest-500 underline-offset-4 hover:underline">
                
                  View full product details
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      }
    </AnimatePresence>);

}
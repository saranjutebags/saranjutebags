import React from 'react';
import { cn } from '../../utils/format';

export function Skeleton({ className }: {className?: string;}) {
  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-xl bg-sand-100/80',
        className
      )}>
      
      <div className="absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent via-white/60 to-transparent" />
    </div>);

}

export function ProductCardSkeleton() {
  return (
    <div className="rounded-4xl border border-ink-line/70 bg-white p-3">
      <Skeleton className="aspect-[4/5] w-full rounded-3xl" />
      <div className="space-y-2.5 px-2 pb-2 pt-4">
        <Skeleton className="h-3 w-20" />
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-3 w-full" />
        <Skeleton className="h-3 w-2/3" />
        <div className="flex items-center justify-between pt-2">
          <Skeleton className="h-5 w-20" />
          <Skeleton className="h-9 w-28 rounded-full" />
        </div>
      </div>
    </div>);

}
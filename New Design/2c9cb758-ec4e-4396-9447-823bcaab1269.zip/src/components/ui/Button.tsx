import React from 'react';
import { Loader2Icon } from 'lucide-react';
import { cn } from '../../utils/format';

type Variant = 'primary' | 'secondary' | 'ghost' | 'glass' | 'danger';
type Size = 'sm' | 'md' | 'lg';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  icon?: React.ReactNode;
  iconRight?: React.ReactNode;
  fullWidth?: boolean;
}

const variants: Record<Variant, string> = {
  primary:
  'bg-forest-700 text-sand-50 hover:bg-forest-600 shadow-soft focus-visible:outline-forest-700',
  secondary:
  'bg-white text-forest-800 border border-ink-line hover:border-forest-300 hover:bg-forest-50 focus-visible:outline-forest-500',
  ghost:
  'bg-transparent text-forest-800 hover:bg-forest-50 focus-visible:outline-forest-500',
  glass:
  'bg-white/70 backdrop-blur-xl text-forest-800 border border-white/70 shadow-glass hover:bg-white/85 focus-visible:outline-forest-500',
  danger:
  'bg-clay text-white hover:bg-[#9C4632] shadow-soft focus-visible:outline-clay'
};

const sizes: Record<Size, string> = {
  sm: 'h-9 px-3.5 text-[13px] gap-1.5 rounded-full',
  md: 'h-11 px-5 text-sm gap-2 rounded-full',
  lg: 'h-[52px] px-7 text-[15px] gap-2.5 rounded-full'
};

export function Button({
  variant = 'primary',
  size = 'md',
  loading = false,
  icon,
  iconRight,
  fullWidth,
  className,
  children,
  disabled,
  ...props
}: ButtonProps) {
  return (
    <button
      {...props}
      disabled={disabled || loading}
      className={cn(
        'inline-flex items-center justify-center font-medium tracking-[-0.01em]',
        'transition-[background-color,border-color,color,transform,box-shadow] duration-200 ease-premium',
        'active:scale-[0.97] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2',
        'disabled:opacity-50 disabled:pointer-events-none whitespace-nowrap',
        variants[variant],
        sizes[size],
        fullWidth && 'w-full',
        className
      )}>
      
      {loading ?
      <Loader2Icon className="h-4 w-4 animate-spin" aria-hidden="true" /> :

      icon
      }
      {children}
      {!loading && iconRight}
    </button>);

}
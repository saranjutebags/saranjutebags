import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2Icon, InfoIcon, XCircleIcon, XIcon } from 'lucide-react';
import { useStore } from '../../contexts/StoreContext';

const icons = {
  success: CheckCircle2Icon,
  error: XCircleIcon,
  info: InfoIcon
};

const tones = {
  success: 'text-forest-500',
  error: 'text-clay',
  info: 'text-sand-600'
};

export function Toaster() {
  const { toasts, dismissToast } = useStore();

  return (
    <div
      className="pointer-events-none fixed inset-x-0 bottom-24 z-[80] flex flex-col items-center gap-2 px-4 sm:bottom-6 sm:right-6 sm:left-auto sm:items-end"
      role="status"
      aria-live="polite">
      
      <AnimatePresence initial={false}>
        {toasts.map((toast) => {
          const Icon = icons[toast.tone];
          return (
            <motion.div
              key={toast.id}
              layout
              initial={{ opacity: 0, y: 12, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.97 }}
              transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
              className="pointer-events-auto flex w-full max-w-sm items-start gap-3 rounded-2xl border border-white/70 bg-white/85 p-3.5 shadow-lift backdrop-blur-xl">
              
              <Icon
                className={`mt-0.5 h-5 w-5 shrink-0 ${tones[toast.tone]}`}
                aria-hidden="true" />
              
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-ink">{toast.title}</p>
                {toast.description &&
                <p className="truncate text-[13px] text-ink-soft">
                    {toast.description}
                  </p>
                }
              </div>
              <button
                onClick={() => dismissToast(toast.id)}
                aria-label="Dismiss notification"
                className="rounded-full p-1 text-ink-muted transition-colors duration-150 ease-premium hover:bg-ink-line/60 hover:text-ink">
                
                <XIcon className="h-4 w-4" aria-hidden="true" />
              </button>
            </motion.div>);

        })}
      </AnimatePresence>
    </div>);

}
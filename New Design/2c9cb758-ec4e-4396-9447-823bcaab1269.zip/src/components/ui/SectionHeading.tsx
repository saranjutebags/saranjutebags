import React from 'react';

interface SectionHeadingProps {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: 'left' | 'center';
  action?: React.ReactNode;
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = 'left',
  action
}: SectionHeadingProps) {
  const centered = align === 'center';
  return (
    <div
      className={
      centered ?
      'mx-auto max-w-2xl text-center' :
      'flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between'
      }>
      
      <div className={centered ? '' : 'max-w-xl'}>
        {eyebrow &&
        <p className="mb-3 text-xs font-semibold uppercase tracking-[0.16em] text-forest-500">
            {eyebrow}
          </p>
        }
        <h2 className="font-display text-3xl leading-[1.15] tracking-[-0.02em] text-forest-800 sm:text-[38px]">
          {title}
        </h2>
        {description &&
        <p className="mt-3 text-[15px] leading-relaxed text-ink-soft">
            {description}
          </p>
        }
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>);

}
import React from 'react';
import { StarIcon } from 'lucide-react';
import { cn } from '../../utils/format';

interface RatingProps {
  value: number;
  reviews?: number;
  size?: 'sm' | 'md';
  className?: string;
}

export function Rating({ value, reviews, size = 'sm', className }: RatingProps) {
  const dim = size === 'sm' ? 'h-3.5 w-3.5' : 'h-4 w-4';
  return (
    <div className={cn('flex items-center gap-1.5', className)}>
      <div
        className="flex items-center gap-0.5"
        role="img"
        aria-label={`Rated ${value} out of 5`}>
        
        {[0, 1, 2, 3, 4].map((i) =>
        <StarIcon
          key={i}
          aria-hidden="true"
          className={cn(
            dim,
            i < Math.round(value) ?
            'fill-sand-400 text-sand-400' :
            'text-ink-line'
          )} />

        )}
      </div>
      <span
        className={cn(
          'font-medium text-ink-soft',
          size === 'sm' ? 'text-xs' : 'text-sm'
        )}>
        
        {value.toFixed(1)}
        {typeof reviews === 'number' &&
        <span className="text-ink-muted font-normal"> ({reviews})</span>
        }
      </span>
    </div>);

}
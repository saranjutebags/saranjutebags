import type { Product } from '../types';

export const products: Product[] = [
{
  id: 'sj-01',
  name: 'Harbour Classic Tote',
  tagline: 'Everyday grocery companion',
  description:
  'Our best-selling jute tote with reinforced cotton rope handles and a laminated interior that wipes clean in seconds.',
  price: 899,
  compareAt: 1299,
  rating: 4.8,
  reviews: 214,
  image: "/458dd06b-dcbd-4928-9d23-3d999bd181a0.jpg",

  category: 'shopping',
  inStock: true,
  badge: 'Bestseller',
  specs: [
  { label: 'Dimensions', value: '38 × 34 × 15 cm' },
  { label: 'Load capacity', value: 'Up to 12 kg' },
  { label: 'Material', value: '100% natural jute, cotton lining' },
  { label: 'Care', value: 'Spot clean, air dry' }]

},
{
  id: 'sj-02',
  name: 'Gift & Giveaway Pouch',
  tagline: 'Small format, big impression',
  description:
  'A compact promotional bag with a deep-green fabric trim — ideal for event giveaways and retail packaging.',
  price: 249,
  compareAt: 349,
  rating: 4.6,
  reviews: 138,
  image: "/eb3995fe-77c9-4d2f-9d98-a99413768a5a.jpg",

  category: 'promotional',
  inStock: true,
  specs: [
  { label: 'Dimensions', value: '22 × 20 × 10 cm' },
  { label: 'Minimum order', value: '50 units' },
  { label: 'Material', value: 'Natural jute, cotton trim' },
  { label: 'Print', value: 'Screen or heat transfer' }]

},
{
  id: 'sj-03',
  name: 'Meridian Work Satchel',
  tagline: 'Structured carry for the office',
  description:
  'A padded 14" laptop compartment wrapped in jute and canvas, finished with vegetable-tanned leather handles.',
  price: 2499,
  compareAt: 3199,
  rating: 4.9,
  reviews: 96,
  image: "/033f1c28-a36f-4fab-ad90-4831af2acddd.jpg",

  category: 'corporate',
  inStock: true,
  badge: 'New',
  specs: [
  { label: 'Fits', value: 'Laptops up to 14"' },
  { label: 'Dimensions', value: '40 × 30 × 12 cm' },
  { label: 'Material', value: 'Jute, waxed canvas, leather' },
  { label: 'Warranty', value: '2 years on stitching' }]

},
{
  id: 'sj-04',
  name: 'Drawstring Keepsake Bag',
  tagline: 'Made to be branded',
  description:
  'A soft drawstring pouch that takes embroidery and print beautifully — our most customised piece.',
  price: 329,
  rating: 4.5,
  reviews: 74,
  image: "/3da1406b-8148-4416-8691-8e4020fdd535.jpg",

  category: 'custom',
  inStock: true,
  specs: [
  { label: 'Dimensions', value: '25 × 30 cm' },
  { label: 'Customisation', value: 'Embroidery, print, tags' },
  { label: 'Lead time', value: '7–10 working days' },
  { label: 'Material', value: 'Fine-weave jute' }]

},
{
  id: 'sj-05',
  name: 'Cellar Wine Carrier',
  tagline: 'Two-bottle divided carrier',
  description:
  'Rigid partitions keep bottles apart and upright, with knotted rope handles that stay comfortable when loaded.',
  price: 599,
  compareAt: 799,
  rating: 4.7,
  reviews: 61,
  image: "/5458b45a-1376-4bd3-b7a1-97c3c93dc755.jpg",

  category: 'promotional',
  inStock: false,
  specs: [
  { label: 'Capacity', value: '2 standard bottles' },
  { label: 'Dimensions', value: '18 × 35 × 9 cm' },
  { label: 'Material', value: 'Natural jute, rigid board base' },
  { label: 'Care', value: 'Spot clean only' }]

},
{
  id: 'sj-06',
  name: 'Shoreline Beach Tote',
  tagline: 'Wide-mouth weekend carry',
  description:
  'An oversized tote with a sand-shedding open weave and thick rope handles built for damp towels and long days.',
  price: 1199,
  compareAt: 1599,
  rating: 4.8,
  reviews: 118,
  image: "/78038eed-09d8-443a-8ace-0762a1a0187e.jpg",

  category: 'shopping',
  inStock: true,
  specs: [
  { label: 'Dimensions', value: '45 × 36 × 18 cm' },
  { label: 'Load capacity', value: 'Up to 15 kg' },
  { label: 'Material', value: 'Open-weave jute, cotton rope' },
  { label: 'Care', value: 'Shake out, air dry' }]

},
{
  id: 'sj-07',
  name: 'Midday Insulated Lunch Bag',
  tagline: 'Keeps meals at temperature',
  description:
  'A food-safe insulated liner inside a jute shell, with a smooth olive zip that opens fully flat.',
  price: 749,
  compareAt: 949,
  rating: 4.4,
  reviews: 88,
  image: "/499f6108-63e3-4825-bcd5-15f3e23390d5.jpg",

  category: 'eco',
  inStock: true,
  specs: [
  { label: 'Dimensions', value: '24 × 18 × 14 cm' },
  { label: 'Insulation', value: 'Recycled PET foil liner' },
  { label: 'Material', value: 'Natural jute shell' },
  { label: 'Care', value: 'Wipe interior clean' }]

},
{
  id: 'sj-08',
  name: 'Trailhead Jute Backpack',
  tagline: 'Two-strap daily carry',
  description:
  'Padded adjustable straps, a brass buckle flap and a hidden back pocket — jute built for a full commute.',
  price: 1899,
  compareAt: 2399,
  rating: 4.7,
  reviews: 52,
  image: "/7578ebb0-67df-43e7-ba2d-1f277a0be327.jpg",

  category: 'eco',
  inStock: true,
  badge: 'Limited',
  specs: [
  { label: 'Volume', value: '18 litres' },
  { label: 'Fits', value: 'Laptops up to 13"' },
  { label: 'Material', value: 'Jute, cotton webbing, brass' },
  { label: 'Warranty', value: '2 years' }]

}];


export const getProduct = (id: string): Product | undefined =>
products.find((p) => p.id === id);
import type { Category, Testimonial } from '../types';

export const heroImage = "/61167866-96e1-4707-9eef-4e0e3f5ca0d8.jpg";


export const juteTexture = "/ae8956e8-2798-4f77-a397-61beb5bb6fb7.jpg";


export const categories: Category[] = [
{
  slug: 'shopping',
  name: 'Shopping Bags',
  blurb: 'Weekly grocery runs and market hauls.',
  image: "/458dd06b-dcbd-4928-9d23-3d999bd181a0.jpg",

  count: 24
},
{
  slug: 'promotional',
  name: 'Promotional Bags',
  blurb: 'Event giveaways that outlive the event.',
  image: "/eb3995fe-77c9-4d2f-9d98-a99413768a5a.jpg",

  count: 18
},
{
  slug: 'corporate',
  name: 'Corporate Bags',
  blurb: 'Structured carry for teams and gifting.',
  image: "/033f1c28-a36f-4fab-ad90-4831af2acddd.jpg",

  count: 12
},
{
  slug: 'custom',
  name: 'Custom Bags',
  blurb: 'Your artwork, woven and printed to order.',
  image: "/3da1406b-8148-4416-8691-8e4020fdd535.jpg",

  count: 9
},
{
  slug: 'eco',
  name: 'Eco Collection',
  blurb: 'Zero-plastic everyday essentials.',
  image: "/7578ebb0-67df-43e7-ba2d-1f277a0be327.jpg",

  count: 16
}];


export const categoryLabel: Record<string, string> = {
  shopping: 'Shopping',
  promotional: 'Promotional',
  corporate: 'Corporate',
  custom: 'Custom',
  eco: 'Eco Collection'
};

export const testimonials: Testimonial[] = [
{
  id: 't1',
  name: 'Ananya Rao',
  role: 'Owner, Fern & Fig Grocers',
  quote:
  'We replaced 4,000 plastic carriers a month with Saran totes. Customers actually keep them, which means our logo keeps walking around the neighbourhood.',
  rating: 5,
  initials: 'AR'
},
{
  id: 't2',
  name: 'Vikram Shetty',
  role: 'Procurement Lead, Northwind',
  quote:
  'The corporate satchels arrived ahead of schedule and the stitching quality held up through a full conference. Reordering for the next two events.',
  rating: 5,
  initials: 'VS'
},
{
  id: 't3',
  name: 'Meera Joseph',
  role: 'Home cook, Kochi',
  quote:
  'Two years of weekly market trips and the handles have not frayed once. It is the only bag I bother to carry now.',
  rating: 4,
  initials: 'MJ'
}];


export const whyChooseUs = [
{
  key: 'eco',
  title: 'Eco-friendly',
  body: 'Jute is biodegradable within a year and absorbs more CO₂ per hectare than most crops.'
},
{
  key: 'durable',
  title: 'Durable',
  body: 'Reinforced seams and double-stitched handles rated for 12–15 kg of everyday load.'
},
{
  key: 'custom',
  title: 'Customizable',
  body: 'Screen print, embroidery or woven labels from just 50 units, with digital proofs first.'
},
{
  key: 'afford',
  title: 'Affordable',
  body: 'Mill-direct sourcing keeps unit costs below imported cotton alternatives at any volume.'
},
{
  key: 'sustain',
  title: 'Sustainable',
  body: 'Farmer co-op supply chain, azo-free dyes and plastic-free packaging on every order.'
}];


export const impactStats = [
{ value: '1.2M', label: 'Plastic bags displaced', detail: 'since 2019' },
{ value: '480 t', label: 'CO₂ absorbed', detail: 'by partner jute farms' },
{ value: '96%', label: 'Biodegrades in 12 months', detail: 'independently tested' },
{ value: '1,400', label: 'Farmer families', detail: 'in our co-op network' }];


export const footerLinks = {
  Company: ['About Saran', 'Our Mill', 'Sustainability Report', 'Careers', 'Press'],
  Products: ['Shopping Bags', 'Promotional Bags', 'Corporate Bags', 'Custom Bags', 'Eco Collection'],
  Support: ['Track Order', 'Shipping & Delivery', 'Returns & Refunds', 'Bulk Enquiry', 'Contact Us'],
  Policies: ['Privacy Policy', 'Terms of Service', 'Cookie Preferences', 'Compliance']
};
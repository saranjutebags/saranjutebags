import React, {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState } from
'react';
import type { CartLine, Order, Product } from '../types';

export interface Toast {
  id: number;
  title: string;
  description?: string;
  tone: 'success' | 'error' | 'info';
}

interface StoreValue {
  cart: CartLine[];
  wishlist: string[];
  orders: Order[];
  toasts: Toast[];
  cartOpen: boolean;
  quickView: Product | null;
  cartCount: number;
  cartSubtotal: number;
  addToCart: (product: Product, qty?: number) => void;
  removeFromCart: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  clearCart: () => void;
  toggleWishlist: (product: Product) => void;
  isWishlisted: (id: string) => boolean;
  openCart: () => void;
  closeCart: () => void;
  setQuickView: (product: Product | null) => void;
  pushToast: (toast: Omit<Toast, 'id'>) => void;
  dismissToast: (id: number) => void;
  placeOrder: (address: string) => Order;
}

const StoreContext = createContext<StoreValue | null>(null);

let toastId = 0;

export function StoreProvider({ children }: {children: React.ReactNode;}) {
  const [cart, setCart] = useState<CartLine[]>([]);
  const [wishlist, setWishlist] = useState<string[]>(['sj-03']);
  const [orders, setOrders] = useState<Order[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [quickView, setQuickView] = useState<Product | null>(null);

  const pushToast = useCallback((toast: Omit<Toast, 'id'>) => {
    const id = ++toastId;
    setToasts((t) => [...t, { ...toast, id }]);
    window.setTimeout(() => {
      setToasts((t) => t.filter((item) => item.id !== id));
    }, 3600);
  }, []);

  const dismissToast = useCallback((id: number) => {
    setToasts((t) => t.filter((item) => item.id !== id));
  }, []);

  const addToCart = useCallback(
    (product: Product, qty = 1) => {
      setCart((current) => {
        const existing = current.find((l) => l.product.id === product.id);
        if (existing) {
          return current.map((l) =>
          l.product.id === product.id ? { ...l, qty: l.qty + qty } : l
          );
        }
        return [...current, { product, qty }];
      });
      pushToast({
        title: 'Added to cart',
        description: product.name,
        tone: 'success'
      });
    },
    [pushToast]
  );

  const removeFromCart = useCallback((id: string) => {
    setCart((current) => current.filter((l) => l.product.id !== id));
  }, []);

  const setQty = useCallback((id: string, qty: number) => {
    setCart((current) =>
    qty <= 0 ?
    current.filter((l) => l.product.id !== id) :
    current.map((l) => l.product.id === id ? { ...l, qty } : l)
    );
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const toggleWishlist = useCallback(
    (product: Product) => {
      setWishlist((current) => {
        const has = current.includes(product.id);
        pushToast({
          title: has ? 'Removed from wishlist' : 'Saved to wishlist',
          description: product.name,
          tone: has ? 'info' : 'success'
        });
        return has ?
        current.filter((id) => id !== product.id) :
        [...current, product.id];
      });
    },
    [pushToast]
  );

  const isWishlisted = useCallback(
    (id: string) => wishlist.includes(id),
    [wishlist]
  );

  const cartCount = useMemo(
    () => cart.reduce((sum, l) => sum + l.qty, 0),
    [cart]
  );

  const cartSubtotal = useMemo(
    () => cart.reduce((sum, l) => sum + l.qty * l.product.price, 0),
    [cart]
  );

  const placeOrder = useCallback(
    (address: string) => {
      const order: Order = {
        id: `SJB-${Math.floor(100000 + Math.random() * 899999)}`,
        placedAt: new Date().toISOString(),
        lines: cart,
        total: cartSubtotal >= 1500 ? cartSubtotal : cartSubtotal + 79,
        status: 'placed',
        address
      };
      setOrders((o) => [order, ...o]);
      setCart([]);
      return order;
    },
    [cart, cartSubtotal]
  );

  const value: StoreValue = {
    cart,
    wishlist,
    orders,
    toasts,
    cartOpen,
    quickView,
    cartCount,
    cartSubtotal,
    addToCart,
    removeFromCart,
    setQty,
    clearCart,
    toggleWishlist,
    isWishlisted,
    openCart: () => setCartOpen(true),
    closeCart: () => setCartOpen(false),
    setQuickView,
    pushToast,
    dismissToast,
    placeOrder
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): StoreValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}